# Fillet v1.0 — selected balance and route rationale

## 1. Intended strength and the evidence boundary

Fillet is a mobile pressure character who earns a temporary speed/strike–throw phase by converting a suitable knockdown into Wound. Her primary opening is high/low pressure; the passing special provides a committed side-change option. Before bleed, ordinary throws interrupt patient defense but do not grant knockdown or repeatable Wound access. During bleed, two finite lunging command grabs threaten cashout. Every successful reset returns enough space to resume interaction.

**These are selected build values, not measured matchup balance.** Numbers below come from `FILLET_SPEC.json` and the captured current Workshop batch at `cd8b0cedabfd508b0d82be2841d640e37928ef91`. `CS_GEOMETRY_RESOLUTION.json` supplies registered geometry checks, not evidence of a fully playtested kit. Implement the numbers as written, run `ACCEPTANCE_TESTS.md`, then evaluate the functioning character. Do not replace this work with another user design audit.

## 2. Position against the current Shark and Smoke normals

The comparison is against **Fight Guild's installed Shark/Ky-derived and Smoke/Queen-Dizzy-derived data**, not a claim about the current balance of Guilty Gear Strive. Each cell below is **startup / active / recovery; base damage**. Startup names the first active tick. Smoke's marked values are damage **per contact group**; actual combo totals scale and require each group to connect.

| Action | Final Fillet | Current Shark | Current Smoke |
|---|---|---|---|
| 5P | 5 / 3 / 9; 24 | 5 / 4 / 7; 26 | 6 / 3 / 10; 25 |
| 5K | 7 / 3 / 13; 32 | 7 / 8 / 6; 30 | 7 / 4 / 12; 26 |
| c.S | 7 / 5 / 12; 44 | 7 / 6 / 10; 42 | 8 / 6 / 12; 43 |
| f.S (`5S`) | 9 / 3 / 18; 40 | 10 / 3 / 20; 34 | 12 / 10 / 19; 10 per group, five groups |
| 5Hs | 13 / 4 / 22; 60 | 12 / 6 / 21; 48 | 12 / 18 / 15; 20 per group, three groups |
| 2K | 6 / 3 / 11; 26 | 6 / 4 / 10; 26 | 6 / 4 / 11; 23 |
| 2S | 12 / 4 / 23; 42 | 11 / 2 / 24; 32 | 10 / 6 / 20; 40 |
| 6P | 9 / 4 / 20; 34 | 9 / 5 / 22; 34 | 12 / 6 / 20; 28 |
| 6Hs | 18 / 4 / 25; 72 | 15 / 4 / 26; 52 | 19 / 8 / 20; 57 |

Fillet's 5P matches Shark's startup with one fewer active tick, two more recovery ticks and two less damage. Her 2K matches Shark's startup/damage with less active coverage. The c.S starter is comparable in speed and raw damage, with a more concentrated registered rising path. Its **72px forward blade tip** is shorter than Shark's 109.60px and Smoke's 121.26px scalar front edges. The **90px proximity selector** measures root distance, not blade length: opponent body extent makes these different quantities. The first active sweep reaches the tested standing/crouching profiles; later high blade keys intentionally can miss a low body.

Fillet f.S is faster than both comparison moves and has a more favorable uncancelled first-contact disadvantage than Shark: **−4 versus −9**, using each move's own blockstun. Its 125px front edge is shorter than Shark's 154.67px or Smoke's 167.28px. Its reaching arm is exposed before activity and into recovery. Smoke's five-group f.S has repeated contacts, push and resource events; comparing its scalar 10 to Fillet's 40 as whole-move damage would be false. Likewise, Smoke's three-group 5Hs is not a 20-damage single swing.

Fillet's heavies buy substantial single-hit damage with startup/recovery commitment and less forward reach: 5Hs reaches 116px versus Shark's 159.39px; 6Hs starts three ticks later than Shark's. Her base walk/run caps, **3.8/11.2px per tick**, sit just below Shark's **3.9/11.5** and above Smoke's **3.4/10.5**. Smoke's run acceleration is 500 raw versus Fillet's 120, so cap alone does not rank approach speed. Fillet's air-dash burst speed matches Smoke's 2000 raw; differing pause/burst durations still matter. Attack friction rises from old Fillet's 45 to 90, limiting carried drift after committing.

Against the **previous Fillet** batch, this is a redistribution rather than a universal increase: c.S changes from 6f/60 damage to 7f/44; f.S from 52 damage with 15 recovery to 40 with 18; 5Hs from 74 to 60. The former 6P's near-neutral block result becomes a more committed anti-air. New pressure routes, exact anatomy and the earned bleed phase replace those broad raw rewards. The wide registered Stalker base also gives opponents honest leg/torso targets; it does not widen Fillet's attack reach or pushbox.

## 3. Pressure structure and deliberate endpoints

First-to-last-active block advantage below assumes uncancelled grounded contact with unchanged clocks and no intervening reaction. Geometry and spacing still determine punishment.

| Tool | Block advantage | Job / cost |
|---|---:|---|
| 5P / 2P | −1…+1 / −1…0 | Compact checks; named light repeats can be pushed out |
| 5K / 2K | −2…0 | Kick pressure; no automatic 2K→2S |
| c.S | +1…+5 | Close starter with limited reach and a changing rising hit path |
| f.S | −4…−2 | Medium poke/continuation; stop or spend a legal cancel |
| 5Hs / 6Hs | −7…−4 / −8…−5 | Damage and commitment; no heavy self-loop |
| 2S | −8…−5 | Low hard knockdown, terminal route |
| 236P | −4…−2 | Normal-cancel mid check, no outgoing route |
| 236S | −3…−1 | Contact-gated pressure entry |
| Crown / Heel | −6…−4 / −9…−7 | Overhead/low finish; terminal on block or hit |
| Passing cut | −10…−8 | Finite side pass with a late strike, not a safe vanish |
| Rising carve | −16…−12 | Grounded launcher/anti-air commitment, no invincible reversal |

The main route family is **light → kick/6P**, or **c.S → f.S/heavy/2S**, followed by the specifically allowed specials. f.S cannot gatling back into c.S. 5Hs can reach 6Hs, but neither creates a heavy self-loop. Air routes are j.P→j.P/j.K→j.S→j.Hs, subject to each named list; the heavy terminates. Jump/air-dash exits require actual permission/quota. No universal whiff cancel, grounded dash cancel or RC rescues a failed commitment.

At first-active c.S contact, an earliest f.S cancel starts immediately after contact and attacks nine advancing ticks later, within 17 blockstun. Delay consumes that margin; latest legal routes can expose actionable opportunities. This is why the input window and a visually continuous bridge do not establish that every timing is a true blockstring.

Opening cut permits only Crown/Heel or its gated bleed grabs. Low startup is **16**, overhead **21**, with completed source frames **9–17** available for branching. Their first five local frames share a standing load; they diverge visibly on frame 6. Varying source delay can defeat one fixed low-then-high guard timing, but later branches also surrender interrupt/escape time. This does not prove an unfuzzyable or unreactable mix. Needle check is a separate normal-cancel endpoint, not a secret third Opening-cut branch. Passing cut travels 150px before a single late facing update and does not force a cross-up if it failed to cross.

## 4. Wound trades oki for a new neutral interaction

Crown and Heel supply **56 Downed ticks** as the intended Wound opportunity. Fillet's 2S has **32**, with 23 recovery; the standard grounded sequence deliberately lacks enough time to recover and start 24f Wound. Current Shark/Smoke sweeps have 36 Downed ticks. Keep natural timing eligibility: counter slow, late active contact, air landing, movement and corner overlap can alter an opportunity. Never add a “sweep may not Wound” whitelist or make every knockdown automatically activate it.

Wound costs the remaining conventional knockdown pressure and deals **zero damage**. Its 20-tick success pair ends at **+0, 120px**, with both standing and victim throw grace. The recipient can defend, contest the next approach or move; Fillet receives the status instead of both a fresh knockdown and guaranteed close pressure. Wound is unavailable while that owned status already exists, so repeated applications cannot reset the clock. A miss commits the full **45 action ticks**.

Ordinary throws remain fast **2/2/32** checks, but successful 45 damage ends standing at **+2 and 120px**, with a six-tick tech opportunity and no Wound route. The 120px separation is chosen outside the authored normal-throw interaction and inside medium-poke play. Plus frames do not override post-stun/release throw grace or close the distance. A throw cannot be cancelled directly from a blockstring.

## 5. Bleed creates a bounded decision, not permanent pressure

The 420-tick clock is seven seconds of **unfrozen combat time**; hitstop lengthens wall-clock duration. There is no ordinary-hit/block refresh. Initial grey is 20; passive growth reaches **59 at tick 419** and clears at tick 420 because expiry precedes growth. Reaching the 160 cap requires active pressure and enough remaining health, not waiting seven seconds. Grey deals no periodic real damage; it is stored potential cashout and is reclamped after target health changes.

Ordinary c.S/f.S block each adds 8 grey, 5Hs adds 12 and Opening cut adds 5. FD adds zero. Hits deal their normal scaled damage without extra grey or refresh. Owner unblocked hit/throw clears the owned status, so defensive success removes both speed and the saved threat. The speed boost sets walk/run/backdash to **4.37/12.88/9.77px per tick**, run acceleration to **1.38px per tick²**, and air-dash/coast to **22/7.15px per tick**. It does not accelerate attack frames, authored travel, gravity, hitstun or grab reach.

Cashout offers **55 + saved grey**, normally starting at 75 and capped at 215 before the health-dependent grey clamp. It consumes status at confirmed capture, so subsequent growth cannot increase the saved payout. Its standing release gives only **+2 at 170px**. Keeping bleed preserves mobility and the threat; spending it yields damage and space, not another guaranteed Wound cycle. Round termination cancels pending release events.

## 6. FD, jump and the two command approaches

FD retains the same **300% block push** for everyone. For c.S/f.S, 6/10px ordinary push becomes 18/30px; multiple blocked contacts can separate a route before its next hit. FD suppresses the block-triggered grey increase, while passive growth still follows its clock. It spends meter: f.S's contact costs 350 units (3.5%) plus continuous drain. It is a spacing/resource defense, not throw immunity by itself.

Both commands travel at most **180px** over frames 6–20, stop at the opposing pushbox and have only the local 20px capture extension beyond combined push edges. They overcome some FD displacement, not arbitrary distance. A cancelled attempt waits five subsequent attacker action ticks after contact, then starts its **22f** startup. Hitstun, blockstun and five post-stun grace ticks still prohibit capture. This creates a defended strike/throw interaction rather than a guaranteed throw combo.

Vault explicitly low-crushes on 6–21 and uses a shallow physical hop; other strikes still test overlap. Skim's ≤52px body avoids rectangles above it, but a mid reaching lower can still hit. “Mid” is a guard category, not a universal hitbox height. Both stand fully vulnerable on capture frames 22–23, and a connecting simultaneous strike/projectile defeats capture.

Both lose to a **valid accepted jump/prejump**; failure is latched from acceptance, including an already airborne target, and never re-arms on landing. Fresh buffered Up must precede grounded FD, while ordinary action/stun locks still apply. Holding Up indefinitely does not synthesize another jump edge. The defender can also interrupt an approach, exploit finite reach or punish a failed 53-tick attempt. Those choices face the surrounding strikes; no single escape is asserted to beat the entire kit.

## 7. What to validate in the playable build

Preserve these selected values while checking actual route reach against each cast hurt profile, FD/corner displacement, maximum-delay branches, 6P/Skim vertical coverage, meaty c.S contact, counter-slow Wound opportunities and command jump/grace boundaries. Medium/large counters use 21/25 and 31/35 freeze/slow, not extra damage or automatic extra numeric hitstun; their held defender ticks can change routes materially.

The acceptance pass must first establish correct rules, exact clocks, consistent art and reproducibility. Playtesting then evaluates how often Fillet reaches c.S, earns Wound, retains bleed and lands cashout against informed defense. No matchup percentage, guaranteed loop, infinite-pressure absence or tournament balance is established by these tables alone. Deliver the complete character with results; tune observed problems afterward rather than replacing the selected design with speculative changes during import.

**Sources:** final `FILLET_SPEC.json`; `FINAL_MOVE_VALUES.json`; `CS_GEOMETRY_RESOLUTION.json`; `ENGINE_IMPLEMENTATION.md`; current `baseline/Current_Workshop_Batch.json`; and `baseline/current_source/docs/move-batches/2026-11-19-slash-sweeps.md`. All comparisons use those installed Fight Guild records and the documented first-active frame convention.
