from pathlib import Path
import json, re, hashlib, argparse

parser=argparse.ArgumentParser()
parser.add_argument('--package',type=Path,required=True)
BASE = parser.parse_args().package.resolve()
HERE = Path(__file__).resolve().parent
batch_raw = (BASE/'baseline/Current_Workshop_Batch.json').read_bytes()
spec_raw = (BASE/'FILLET_SPEC.json').read_bytes()
batch, spec = json.loads(batch_raw), json.loads(spec_raw)
header=(BASE/'baseline/current_source/core/fight.h').read_text()
def enum_names(k): return [s.strip() for s in re.search(r'enum '+k+r'\s*\{([^}]+)\}',header,re.S).group(1).split(',') if s.strip()]
def camel(k): return ('fd'+k[2:]) if k.startswith('FD') else k[:1].lower()+k[1:]
fields=[camel(k) for k in enum_names('Field')]
movement_aliases={'MovePrejumpFrames':'prejumpFrames','MoveSmearMode':'smearMode','MoveSmearPart':'smearPart','MoveSmearStretch':'smearStretch'}
mobility=[movement_aliases.get(k,camel(k)) for k in enum_names('MobilityField') if k!='MOBILITY_FIELDS']
ids=[m['id'] for m in batch['characters'][0]['moves']]
assert len(fields)==138 and len(ids)==45

def move_lines(c, slot, scalars, hurt, track):
    out=[f's.moves[{c}][{slot}].v[{n}]={scalars[key]};' for n,key in enumerate(fields)]
    for phase,label in enumerate(['windup','active','recovery']):
        boxes=hurt.get(label,{})
        out.append(f's.move_hurt[{c}][{slot}][{phase}].count={len(boxes)};')
        for i,name in enumerate(['legs','torsoArms','head','extension']):
            if name in boxes: out.append(f's.move_hurt[{c}][{slot}][{phase}].boxes[{i}]={{'+','.join(map(str,boxes[name]))+'};')
    out.append(f's.move_hit[{c}][{slot}].count={len(track["keys"])};s.move_hit[{c}][{slot}].multi={int(track["multiHit"])};')
    for n,key in enumerate(track['keys']):
        boxes=key['boxes']; vals=[key['frame'],key['hit'],-1 if boxes is None else len(boxes)]+[key[k] for k in ['damage','hitstun','blockstun','hitstop']]
        out.append(f's.move_hit[{c}][{slot}].keys[{n}]={{'+','.join(map(str,vals))+',{'+','.join('{'+','.join(map(str,b))+'}' for b in (boxes or []))+'}};')
    return out

lines=['// Exact latest Workshop batch. No core or repository mutation.','static void load_batch(fight::Simulation& s) { s.defaults();']
for c,char in enumerate(batch['characters']):
    for slot,move in enumerate(char['moves']):
        assert move['id']==ids[slot]
        lines+=move_lines(c,slot,move,move['hurtboxes'],move['hitboxTimeline'])
    lines += [f's.mobility[{c}].v[{n}]={char["movement"][k]};' for n,k in enumerate(mobility)]
rule_values={k:v for section in ['inputRules','momentumRules','recoveryRules','tuningRules','jumpRules'] for k,v in batch[section].items()}
rule_aliases={'MoveGain':'movementGain','BlockAttackGain':'blockedAttackGain','DamageGain':'damageTakenGain'}
for at,name in enumerate(k for k in enum_names('Rule') if k!='RULE_COUNT'):
    key=rule_aliases.get(name,camel(name));lines.append(f's.rule_set({at},{rule_values[key]});')
lines.append('}')
(HERE/'current_batch.h').write_text('\n'.join(lines)+'\n')
selected=[a for a in spec['actions'] if a['id'] in ['c.S','5S']]
lines=['// Final c.S/f.S values only. Exact hit tracks; legacy 3-phase hurt fallback.','static void load_selected(fight::Simulation& s) {','s.mobility[5].v[fight::AttackFriction]=90;']
for a in selected: lines+=move_lines(5,a['slot'],a['schema22Scalars'],a['legacyHurtPhaseFallback'],a['hitboxTimeline'])
lines.append('}')
(HERE/'selected.h').write_text('\n'.join(lines)+'\n')
metadata={'sourceCommit':spec['sourceCommit'],'batchSHA256':hashlib.sha256(batch_raw).hexdigest(),'specSHA256AtRead':hashlib.sha256(spec_raw).hexdigest(),'selectedActions':[{'id':a['id'],'slot':a['slot'],'schema22Scalars':a['schema22Scalars'],'hitboxTimeline':a['hitboxTimeline'],'legacyHurtPhaseFallback':a['legacyHurtPhaseFallback']} for a in selected],'attackFriction':90,'noProximityBypass':True,'sourceFiles':{str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'baseline/current_source/core').iterdir() if p.is_file()}}
(HERE/'probe_inputs.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({k:v for k,v in metadata.items() if k!='selectedActions'},indent=2))
