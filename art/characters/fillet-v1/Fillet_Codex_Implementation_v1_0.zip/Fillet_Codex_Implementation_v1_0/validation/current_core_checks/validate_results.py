import json
from pathlib import Path
here=Path(__file__).resolve().parent
rows=list(map(json.loads,(here/'results.jsonl').read_text().splitlines()))
assert len(rows)==37
errors=[]
def check(ok,label,row):
    if not ok:errors.append({'check':label,'row':row})
for r in rows:
    if r['kind']=='selector':
        check(r['selected']==(32 if r['gap']<=9000 else 2),'selector boundary',r)
        check(r['age']==1,'real input begins action frame1',r)
        continue
    check(r['initialSelected']==32 and r['firstTick']==6,'real-input c.S first active',r)
    if r['bufferOffset'] in [1,4]:
        check(r['secondTick']==-1 and r['fsStartTick']==-1,'expired input is rejected',r)
        continue
    check(r['secondTick']>=0,'far S connects',r)
    check(r['unfrozenTicksSinceFirst']==r['cancelAge']-7+9,'contact timing',r)
    check(r['frozenTicksSinceFirst']==8,'ordinary shared hitstop',r)
    check(r['fsStartTick']>=0 and r['secondTick']-r['fsStartTick']==8,'f.S active9',r)
    if r['mode']==2:
        check((r['firstDamage'],r['secondDamage'])==(44,32),'normal hit damage/scaling',r)
    else:
        check(r['priorStunAtSecond']==max(0,16-r['cancelAge']),'continuous/gap boundary',r)
        cs_push,fs_push=(1800,3000) if r['mode']==5 else (600,1000)
        check(r['firstGap']==r['gap']+cs_push,'c.S block push',r)
        check(r['secondGap']==r['gap']+cs_push+fs_push,'f.S block push',r)
        check(r['secondEvent']==2,'guarded second contact',r)
summary={'cases':len(rows),'routeCases':sum(r['kind']=='route' for r in rows),'selectorCases':sum(r['kind']=='selector' for r in rows),'expectedExpiredInputs':2,'failedAssertions':len(errors),'errors':errors,'status':'passed' if not errors else 'failed','scope':'current-core c.S/f.S input routing, selected hitboxes, contact timing, guard/FD push and ordinary damage only; no future extensions implemented'}
(here/'validation_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
raise SystemExit(bool(errors))
