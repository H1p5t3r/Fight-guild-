#include "fight.h"
#include <iostream>
#include "current_batch.h"
#include "selected.h"
using namespace fight;
static Simulation s;

static void setup(int actor,int gap,int sign,bool corner) {
 load_batch(s);load_selected(s);s.reset(actor==0?5:4,actor==0?4:5,0,0);
 int dx=corner?(sign>0?97000:3000):40000+sign*gap;
 int ax=dx-sign*gap;
 s.preview_place(actor,ax,0,10000);s.preview_place(1-actor,dx,0,10000);
}

// Real input starts c.S and requests f.S. mode2=normalhit,4=downback,5=downbackFD.
static void route(int gap,int mode,int cancelAge=7,int sign=1,bool corner=false,int actor=0,int bufferOffset=-1) {
 setup(actor,gap,sign,corner);
 int selected=-1,first=-1,second=-1,request=-1,fsStart=-1,firstGap=-1,secondPreGap=-1,secondGap=-1;
 int firstDamage=-1,secondDamage=-1,firstStop=-1,secondStop=-1,priorStun=-1,event=-1,unfrozen=0,frozen=0;
 bool asked=false;
 for(int t=0;t<140;++t){
  auto&a=s.world.players[actor];auto&b=s.world.players[1-actor];
  bool stop=s.world.hitstop>0;
  int def=mode==2?0:(sign>0?Right:Left)|Down;
  if(mode==5)def|=Faultless;
  bool ask=false;
  if(!asked&&first>=0&&a.move==32) ask=bufferOffset>=0?t-first==bufferOffset:!stop&&a.age>=cancelAge;
  int atk=t==0?S:ask?S:0;
  if(ask){asked=true;request=t;}
  int old=a.contact_count,stun=b.stun,before=(b.x-a.x)*sign;
  if(first>=0){if(stop)++frozen;else ++unfrozen;}
  s.step(actor==0?atk:def,actor==0?def:atk);
  if(t==0)selected=a.move;
  if(a.move==2&&fsStart<0)fsStart=t;
  if(a.contact_count>old){
   if(first<0){first=t;firstGap=(b.x-a.x)*sign;firstDamage=a.last_damage;firstStop=s.world.hitstop;}
   else{second=t;secondPreGap=before;secondGap=(b.x-a.x)*sign;secondDamage=a.last_damage;secondStop=s.world.hitstop;priorStun=stun;event=a.event;break;}
  }
 }
 std::cout<<"{\"kind\":\"route\",\"actor\":"<<actor<<",\"sign\":"<<sign<<",\"corner\":"<<(corner?"true":"false")<<",\"gap\":"<<gap<<",\"mode\":"<<mode<<",\"cancelAge\":"<<cancelAge<<",\"bufferOffset\":"<<bufferOffset<<",\"initialSelected\":"<<selected<<",\"firstTick\":"<<first<<",\"firstGap\":"<<firstGap<<",\"firstDamage\":"<<firstDamage<<",\"firstHitstop\":"<<firstStop<<",\"requestTick\":"<<request<<",\"fsStartTick\":"<<fsStart<<",\"secondTick\":"<<second<<",\"secondPreGap\":"<<secondPreGap<<",\"secondGap\":"<<secondGap<<",\"secondDamage\":"<<secondDamage<<",\"secondHitstop\":"<<secondStop<<",\"priorStunAtSecond\":"<<priorStun<<",\"secondEvent\":"<<event<<",\"frozenTicksSinceFirst\":"<<frozen<<",\"unfrozenTicksSinceFirst\":"<<unfrozen<<"}\n";
}

static void selector(int gap,int sign,int actor) {
 setup(actor,gap,sign,false);s.step(actor==0?S:0,actor==0?0:S);
 std::cout<<"{\"kind\":\"selector\",\"actor\":"<<actor<<",\"sign\":"<<sign<<",\"gap\":"<<gap<<",\"selected\":"<<s.world.players[actor].move<<",\"age\":"<<s.world.players[actor].age<<"}\n";
}

int main(){
 for(int mode:{2,4,5})for(int gap:{6200,9000})route(gap,mode);
 for(int sign:{-1,1})for(int mode:{4,5})route(6200,mode,7,sign,true);
 for(int sign:{-1,1})for(int mode:{4,5})route(6200,mode,7,sign,false,1);
 for(int age=8;age<=17;++age)route(6200,4,age);
 route(6200,2,17);
 for(int offset:{1,4,5,8})route(6200,4,7,1,false,0,offset);
 for(int actor:{0,1})for(int sign:{-1,1})for(int gap:{9000,9001})selector(gap,sign,actor);
}
