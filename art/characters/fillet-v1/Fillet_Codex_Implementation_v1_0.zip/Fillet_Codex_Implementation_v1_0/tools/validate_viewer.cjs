const fs=require('fs'),vm=require('vm'),path=require('path');
const file=path.resolve(__dirname,'../FRAME_VIEWER.html');
const html=fs.readFileSync(file,'utf8'),payload=html.match(/<script id="data" type="application\/json">([\s\S]*?)<\/script>/)[1],script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const data=JSON.parse(payload),nodes={};
const get=id=>nodes[id]||(nodes[id]={value:id==='action'?'5P':id==='frame'?'1':'',checked:false,max:1,innerHTML:'',textContent:id==='data'?payload:'',setAttribute(k,v){this[k]=v;}});
const context={document:{getElementById:get}};vm.createContext(context);vm.runInContext(script,context);
let frames=0;
for(const action of data.spec.actions){
 get('action').value=action.id;vm.runInContext('select()',context);
 if(!get('properties').innerHTML.includes('counterFreezeFrames'))throw Error('Missing property list '+action.id);
 for(let i=1;i<=action.timing.totalWhiffTicks;i++){
  get('frame').value=i;vm.runInContext('render()',context);const f=JSON.parse(get('exact').textContent);
  if(f.move!==action.id||f.frame!==i)throw Error('Wrong frame '+action.id+' '+i);
  if(/NaN|undefined/.test(get('plot').innerHTML))throw Error('Invalid svg '+action.id+' '+i);
  frames++;
 }
 get('mirror').checked=true;get('root').checked=true;vm.runInContext('render()',context);get('mirror').checked=false;get('root').checked=false;
}
console.log(JSON.stringify({actions:data.spec.actions.length,framesRendered:frames,propertyLists:'all complete',mirroredAuthoredTravel:'all rendered',limitation:'logic/SVG generation only; no browser layout or engine simulation'}));
