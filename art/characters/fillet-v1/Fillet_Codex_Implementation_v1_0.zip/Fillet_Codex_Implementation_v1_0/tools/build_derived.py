#!/usr/bin/env python3
"""Regenerate human-readable and visual views from the selected Fillet contract.

Standard library only. Does not alter authoritative design or any game repository.
"""
from pathlib import Path
import copy
import html
import json
import re

ROOT = Path(__file__).resolve().parents[1]
SPEC = json.loads((ROOT / 'FILLET_SPEC.json').read_text())
ESC = html.escape

def dump(value):
    return json.dumps(value, ensure_ascii=False, indent=2)

def signed(value):
    return '—' if value is None else f'{value:+d}'

def row(values):
    return '| ' + ' | '.join(str(x).replace('|', '\\|').replace('\n', ' ') for x in values) + ' |'

def table(headers, rows):
    return '\n'.join([row(headers), row(['---'] * len(headers))] + [row(x) for x in rows]) + '\n'

def hold(keys, frame):
    return max((k for k in keys if k['frame'] <= frame), key=lambda k: k['frame'])

def expanded_frames():
    result = []
    for action in SPEC['actions']:
        v = action['schema22Scalars']
        for frame in range(1, action['timing']['totalWhiffTicks'] + 1):
            phase = 'startup' if frame < v['startup'] else 'active' if frame < v['startup'] + v['active'] else 'recovery'
            body = copy.deepcopy(hold(action['hurtboxTimeline']['keys'], frame)['boxes'])
            if action['id'] == '6P' and 3 <= frame <= 12:
                body = {k: b for k, b in body.items() if k == 'legs'}
            hit = []
            if phase == 'active' and action['hitboxTimeline']['keys']:
                hit = copy.deepcopy(hold(action['hitboxTimeline']['keys'], frame - v['startup'] + 1)['boxes'])
            push = copy.deepcopy(action['pushbox']['air' if v['air'] else 'ground'])
            if action.get('pushboxTimeline'):
                push = copy.deepcopy(hold(action['pushboxTimeline']['keys'], frame)['box'])
            dx = v['startupTravel'] if phase == 'startup' else v['travelSpeed'] if phase == 'active' else 0
            dx += sum(t['dx'] for t in action['movement']['rootTrack'] if t['first'] <= frame <= t['last'])
            y = None
            if action['movement'].get('verticalRootKeys'):
                keys = action['movement']['verticalRootKeys']
                prev = hold(keys, frame)
                nxt = min((k for k in keys if k['frame'] >= frame), key=lambda k: k['frame'], default=prev)
                y = prev['y'] if prev['frame'] == nxt['frame'] else prev['y'] + int((nxt['y'] - prev['y']) * (frame - prev['frame']) / (nxt['frame'] - prev['frame']))
            result.append({'move': action['id'], 'frame': frame, 'phase': phase,
                           'hitboxes': hit, 'hurtboxes': body, 'pushbox': push,
                           'captureAttempt': bool(action.get('capture')) and phase == 'active',
                           'woundAttempt': action['id'] == '5D' and phase == 'active',
                           'lowCrush': action['id'] == '236D' and 6 <= frame <= 21,
                           'rootAuthoredDX': dx, 'verticalRootOverride': y,
                           'inertiaSeparate': True, 'contactGroup': 1 if hit else 0})
    return result

def write_move_book():
    out = ['# Fillet — complete move specification', '',
           'Selected v1.0 build data. Implement every enabled action. This is a readable projection of `FILLET_SPEC.json`; the JSON and `ENGINE_IMPLEMENTATION.md` define the exact behavior. `FINAL_MOVE_VALUES.json` contains all 138 scalar values for every one of the 47 stable slots, including the 21 explicitly disabled slots. `PROPERTY_REFERENCE.json` explains each scalar, units, applicability and inherited source behavior. No unlisted special effect is implied by an animation or by a donor reference.', '',
           '## Conventions', '',
           '60 simulation ticks per second. Raw coordinates use 100 units per pixel. Rectangles are `[left,bottom,right,top]`, local to the fighter root, facing right, with positive Y upward. Mirror X as `[-right,bottom,-left,top]`. Body rectangles below are complete records at each key; absent extension means absent. Hold a record until its next key. Strike keys are active-relative; all body, push, root and pose keys are absolute action frames.', '',
           'Startup S names the first active frame. The complete whiff duration is S−1+A+R. Frame advantage is measured from first-active contact unless stated otherwise, excluding equal shared freeze. Later contact can improve advantage by the elapsed active frames. Counter freeze is the total shared freeze, followed by alternating defender slow ticks; it is not an additional freeze on top of ordinary hitstop. Capture/Wound success replaces the remaining ordinary action and uses its dedicated pair clocks.', '',
           'Exact per-frame diagrams: `FRAME_VIEWER.html` and `ACTION_ATLAS.html`. Production posing, every locomotion/defense transition and both roles of every grab: `ANIMATION_AND_ART.md`. Visual donor provenance: `VISUAL_REFERENCE_INDEX.md`.', '',
           '## Whole kit', '']
    overview = []
    for a in SPEC['actions']:
        v, t = a['schema22Scalars'], a['timing']
        damage = a.get('capture', {}).get('damage', str(v['damage']))
        overview.append([a['inputLabel'], a['name'], f"{v['startup']}/{v['active']}/{v['recovery']}", damage,
                         signed(t['blockAdvantageFirstActive']), a['contacts']['block'],
                         f"{t['counterTotalFreeze']}/{t['counterSlowTicks']}/{t['counterExtraHitstun']}" if t['counterApplies'] else 'not a strike'])
    out += [table(['Input', 'Move', 'S/A/R', 'Damage', 'Block', 'Guard / contact', 'CH freeze/slow/extra stun'], overview),
            '## Shared behavior', '',
            'Ordinary strikes use one contact group, no armor, no guard point, no projectile, no general strike invulnerability, no whiff cancel and no RC. Explicit exceptions are fully specified below: 6P masks upper anatomy on frames 3–12; Vault low-crush lasts 6–21; Skim evasion is geometric on 6–21. These protections end before command capture. Fillet has no invulnerable reversal. Ordinary attack recovery is throwable unless a separate protected state applies.', '',
            'Entry inertia is sampled once from eligible current/carry velocity; signed division truncates toward zero. Apply authored travel separately, then 90 raw units of attack friction per advancing actor tick. Do not reapply movement bonuses during a chain. Source contact hitstop holds the resolved pose and roots. A legal cancel replaces the old animation immediately, without its recovery or a transition tax.', '',
            'Normal-route and special-route lists are exact allowlists. Scalar route masks are compatibility metadata, not permission to add extra destinations. Empty list means no route. A contact-gated move cannot cancel on whiff. Bleed-grab routes need owned bleed and at least five completed attacker action ticks since the last contact in the permitted special/follow window. `2K→2S` is excluded. Neutral S uses c.S at ≤90px center spacing; legal c.S→S selects f.S regardless of that selector.', '',
            '### Bleed', '', '```json', dump(SPEC['bleed']), '```', '',
            '### Ground normal-throw tech', '', '```json', dump(SPEC['normalThrowTech']), '```', '']
    grouped_fields = {
        'Hit result and push': ['damage','hitstun','blockstun','hitstop','hitLevel','pushback','airPushback','blockPushback','launch','airLaunch','knockdown','knockdownFrames','wakeupFrames','hitAngle','chipDamage','guardBreak','groundBounce','wallBounce','crumpleFrames','airCounterKnockdown'],
        'Counter, vulnerability and landing': ['counterTier','counterVulnerable','counterFreezeFrames','counterSlowFrames','counterHitstun','counterHitstop','reversalEligible','hurtMaskWindup','hurtMaskActive','hurtMaskRecovery','hurtWindowStart','hurtWindowEnd','hurtWindowMask','semiAirStart','semiAirEnd','armorFrames','armorHits','landingRecovery'],
        'Scaling and route windows': ['starterProration','comboScaling','minimumDamage','normalCancelStart','normalCancelEnd','specialCancelStart','specialCancelEnd','jumpCancelStart','jumpCancelEnd','followCancelStart','followCancelEnd','cancelOn','followFrom','followFrom2','followHit','proximityMove','proximityRange'],
    }
    for n, a in enumerate(SPEC['actions'], 1):
        v, t = a['schema22Scalars'], a['timing']
        out += [f"## {n:02d}. {a['inputLabel']} — {a['name']}", '', a['role'], '',
                f"**Stable slot:** {a['slot']}. **Input:** {a['inputLabel']}. **Animation clip:** `{a['animation']['clipId']}`.", '',
                table(['Property', 'Selected result'], [
                    ['Startup / active / recovery', f"{v['startup']} / {v['active']} / {v['recovery']}"],
                    ['Absolute active frames', f"{t['activeFrames'][0]}–{t['activeFrames'][1]}"],
                    ['Recovery / next neutral', f"{t['recoveryFrames'][0]}–{t['recoveryFrames'][1]}; next neutral {t['nextNeutralTick']}"],
                    ['Block advantage first / last active', f"{signed(t['blockAdvantageFirstActive'])} / {signed(t['blockAdvantageLastActive'])}"],
                    ['Counter', f"Total shared freeze {t['counterTotalFreeze']}; slow {t['counterSlowTicks']} ({t['counterExtraHeldTicks']} extra held ticks); +{t['counterExtraHitstun']} hitstun; applies={t['counterApplies']}"],
                    ['Ordinary freeze', t['ordinaryHitstop']],
                    ['Entry inertia', f"{v['inertiaPercent']}%"],
                ])]
        for title, fields in grouped_fields.items():
            out += [f'### {title}', '', table(['Scalar', 'Value'], [[f'`{k}`', v[k]] for k in fields])]
        out += ['### Contact predicates and complete routes', '', '```json', dump({'contacts': a['contacts'], 'cancels': a['cancels']}), '```', '']
        if a.get('capture') or a.get('wound'):
            out += ['### Successful paired branch and failed attempt', '', '```json', dump(a.get('capture') or a['wound']), '```', '']
        out += ['### Momentum, root travel, facing and resources', '', '```json', dump({'movement': a['movement'], 'meterAndScaling': a['meterAndScaling']}), '```', '',
                '### Exact attack rectangles', '',
                table(['Active-relative key', 'Absolute frame', 'Hit group', 'Rectangles — raw units'],
                      [[k['frame'], v['startup'] + k['frame'] - 1, k['hit'], json.dumps(k['boxes'])] for k in a['hitboxTimeline']['keys']]) if a['hitboxTimeline']['keys'] else 'No strike rectangles. Capture uses explicit eligibility and push-edge distance, with a separate non-damaging visualization guide.\n', '',
                '### Exact anatomical rectangles', '',
                table(['Absolute key', 'Regions — raw units'], [[k['frame'], json.dumps(k['boxes'], separators=(',', ':'))] for k in a['hurtboxTimeline']['keys']]), '',
                '6P applies its legs-only mask after this body lookup on frames 3–12.' if a['id'] == '6P' else 'No additional anatomy mask beyond the explicitly listed scalar/window contract.', '',
                '### Push shape and pose schedule', '', '```json', dump({'pushbox': a['pushbox'], 'pushboxTimeline': a.get('pushboxTimeline'), 'poseKeys': a['animation']['keys']}), '```', '',
                '### Animation and state transfers', '', '```json', dump({k:a['animation'][k] for k in ['entrySources','impactInsert','exit','interrupt','specificStaging']}), '```', '',
                f"Geometry sheet: `geometry/{a['slot']:02d}.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.", '']
    out += ['## Disabled Fillet slots', '',
            'Keep these stable IDs for serialization; set enabled=0 for Fillet. Do not remove/reorder existing cast slots or disable other characters’ attacks. Append command-grab slots disabled for other characters.', '',
            table(['Slot','ID','Reason'], [[d['slot'],d['id'],d['reason']] for d in SPEC['disabledStableSlots']]), '',
            '## Remaining scalar fields', '',
            'Every scalar not repeated in these readable tables remains explicitly selected in `FINAL_MOVE_VALUES.json`. In particular, the inactive projectile/tether/stance/smear variants and legacy art compatibility values are not permission to enable those mechanics. `enabled`, action categories, input mappings and the sidecar types determine applicability. Do not infer absent effects from nonzero compatibility defaults. `PROPERTY_REFERENCE.json` provides their definitions and the baseline source citations.', '']
    (ROOT / 'ALL_MOVES.md').write_text('\n'.join(out))

def svg_box(b, color, opacity=.14, dash=''):
    l, bot, r, top = [x / 100 for x in b]
    return f'<rect x="{l:g}" y="{-top:g}" width="{r-l:g}" height="{top-bot:g}" fill="{color}" fill-opacity="{opacity}" stroke="{color}" stroke-width="1" {dash}/>'

def make_atlas(frames):
    by = {a['id']: [f for f in frames if f['move'] == a['id']] for a in SPEC['actions']}
    folder = ROOT / 'geometry'
    folder.mkdir(exist_ok=True)
    cards = []
    for a in SPEC['actions']:
        v = a['schema22Scalars']
        picks = [1, v['startup'] - 1, v['startup'], v['startup'] + v['active'], a['timing']['totalWhiffTicks']]
        panels = []
        for i, n in enumerate(picks):
            f = by[a['id']][n - 1]
            tags = [f'<text x="{i*236+18}" y="80" fill="#d4e4f3" font-size="14">f{n} · {f["phase"]}</text>', f'<g transform="translate({i*236+96} 282)">']
            tags += [f'<line x1="-65" y1="0" x2="145" y2="0" stroke="#64798d"/>', svg_box(f['pushbox'], '#e9c766', .06)]
            tags += [svg_box(b, '#67d9b0') for b in f['hurtboxes'].values()]
            tags += [svg_box(b, '#ff7383', .3) for b in f['hitboxes']]
            if f['captureAttempt']:
                tags += [svg_box(a['capture']['localCaptureGuideBox'], '#cc9bff', .18, 'stroke-dasharray="3 2"')]
            tags += ['<circle cx="0" cy="0" r="2.5" fill="#ffffff"/>', '<text x="3" y="16" fill="#b2c6d9" font-size="9">root · x=0</text>', '</g>',
                     f'<text x="{i*236+18}" y="316" fill="#a8bed2" font-size="11">local, y-up · 100 raw = 1px</text>']
            panels += tags
        title = f"{a['inputLabel']} — {a['name']}"
        subtitle = f"S/A/R {v['startup']}/{v['active']}/{v['recovery']} · {v['damage']} base damage · block {signed(a['timing']['blockAdvantageFirstActive'])} · {v['inertiaPercent']}% inertia"
        svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="1180" height="376" viewBox="0 0 1180 376"><rect width="1180" height="376" rx="14" fill="#0e1b29"/><g font-family="DejaVu Sans,Arial,sans-serif"><text x="18" y="28" fill="#f0f6fc" font-size="21" font-weight="bold">{ESC(title)}</text><text x="18" y="50" fill="#abc4da" font-size="13">{ESC(subtitle)}</text>{''.join(panels)}<text x="18" y="350" fill="#8da8c0" font-size="12">Green anatomy · red strike · gold push · purple capture guide (not a hitbox). Every intermediate tick is in FRAME_VIEWER.</text><text x="18" y="367" fill="#8da8c0" font-size="11">Root-local geometry; authored travel, entry inertia, Vault arc and stage/target constraints are separate. No sprites are implied by these rectangles.</text></g></svg>'''
        (folder / f"{a['slot']:02d}.svg").write_text(svg)
        cards.append(f'<section><h2>{ESC(title)}</h2><p>{ESC(a["role"])}</p><img src="geometry/{a["slot"]:02d}.svg" alt="Five exact phase snapshots for {ESC(a["inputLabel"])}"><p>Complete frame data and posing: ALL_MOVES.md · ANIMATION_AND_ART.md · VISUAL_REFERENCE_INDEX.md</p></section>')
    (ROOT / 'ACTION_ATLAS.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fillet · complete action atlas</title><style>body{margin:0;background:#08111c;color:#e6eff8;font:16px/1.6 system-ui,sans-serif}main{max-width:1240px;margin:auto;padding:32px}h1{font-size:36px}a{color:#81c9ff}section{margin:28px 0;padding:20px;border:1px solid #25405b;border-radius:16px;background:#0d1926}img{width:100%;height:auto}p{color:#b7ccdf}h2{margin:0}</style><main><h1>Fillet — all 26 actions</h1><p>Selected implementation geometry, v1.0. Five root-local snapshots per action, with all intervening ticks in the <a href="FRAME_VIEWER.html">interactive frame viewer</a>. These exact diagrams guide collision and registration. The production pose descriptions and reference images supply the character acting. Capture guides are explanatory; real grab range is additional gap beyond both fighters’ push edges.</p><p>Use <a href="CS_REGISTERED_ACTIVE_GUIDE.svg">the registered c.S guide</a> for the selected fixed-length short-knife rig and six-frame blade sweep.</p>''' + ''.join(cards) + '</main></html>')

def build_viewer(frames):
    template = (ROOT / 'tools/frame_viewer_template.html').read_text()
    dictionary = json.loads((ROOT / 'PROPERTY_REFERENCE.json').read_text())
    payload = {'spec': SPEC, 'frames': {a['id']:[f for f in frames if f['move']==a['id']] for a in SPEC['actions']},
               'dictionary': {p['key']:p for p in dictionary['properties']}}
    result = template.replace('[PAYLOAD]', json.dumps(payload, separators=(',', ':'), ensure_ascii=False).replace('</', '<\\/'))
    (ROOT / 'FRAME_VIEWER.html').write_text(result)

def main():
    frames = expanded_frames()
    (ROOT / 'FRAME_GEOMETRY.jsonl').write_text(''.join(json.dumps(f,separators=(',',':'))+'\n' for f in frames))
    (ROOT / 'MOVEMENT_ANIMATION.json').write_text(dump(SPEC['movementContract'])+'\n')
    write_move_book()
    make_atlas(frames)
    build_viewer(frames)
    print(json.dumps({'actions':len(SPEC['actions']),'expandedFrames':len(frames),'geometrySheets':len(SPEC['actions']),'generated':['ALL_MOVES.md','ACTION_ATLAS.html','FRAME_VIEWER.html','FRAME_GEOMETRY.jsonl','MOVEMENT_ANIMATION.json']}))

if __name__ == '__main__':
    main()
