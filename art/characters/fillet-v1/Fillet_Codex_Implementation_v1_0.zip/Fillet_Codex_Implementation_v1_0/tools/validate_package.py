#!/usr/bin/env python3
"""Static integrity checks only; not a substitute for in-engine acceptance tests."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[1]
errors = []
checks = 0

def check(condition, label):
    global checks
    checks += 1
    if not condition:
        errors.append(label)

def load(name):
    return json.loads((ROOT / name).read_text())

def box_ok(b):
    return isinstance(b,list) and len(b)==4 and all(type(x) is int for x in b) and b[0]<b[2] and b[1]<b[3]

def timeline(keys, last, label):
    ticks = [k['frame'] for k in keys]
    check(bool(ticks) and ticks[0]==1 and ticks==sorted(set(ticks)) and ticks[-1]<=last, label)

spec = load('FILLET_SPEC.json')
actions = spec['actions']
disabled = spec['disabledStableSlots']
by = {a['id']:a for a in actions}
records = actions + disabled
matrix = load('FINAL_MOVE_VALUES.json')
fields = matrix['fieldOrder']
dictionary = {d['key']:d for d in load('PROPERTY_REFERENCE.json')['properties']}
check(len(actions)==26 and len(disabled)==21, '26 enabled / 21 disabled inventory')
check(len(by)==26 and len({a['id'] for a in records})==47, 'unique move IDs')
check(sorted(a['slot'] for a in records)==list(range(47)), 'stable slots exactly 0..46')
check(len(fields)==138 and len(set(fields))==138 and set(fields)==set(dictionary), '138 defined scalar fields')
check(spec['sourceBatchSHA256']==hashlib.sha256((ROOT/'baseline/Current_Workshop_Batch.json').read_bytes()).hexdigest(), 'baseline batch digest')
check(spec['movementContract']==load('MOVEMENT_ANIMATION.json'), 'movement extraction matches canonical')
mr = {x['slot']:x for x in matrix['records']}
for a in records:
    v = a['schema22Scalars']
    check(set(v)==set(fields), f"{a['id']} exact scalar coverage")
    check(mr[a['slot']]['id']==a['id'] and mr[a['slot']]['values']==v, f"{a['id']} scalar matrix matches")
    check(v['enabled']==(1 if a in actions else 0), f"{a['id']} selected enabled state")
    for key,value in v.items():
        limits = dictionary[key]['validation']
        check(type(value) is int, f"{a['id']}.{key} integer")
        upper=limits['maximum'] if isinstance(limits['maximum'],int) else limits['maximum']['per_character']['Fillet']
        check(limits['minimum']<=value<=upper, f"{a['id']}.{key} out of bounds {value}")
for a in actions:
    aid=a['id'];v=a['schema22Scalars'];t=a['timing'];total=v['startup']-1+v['active']+v['recovery']
    check(total==t['totalWhiffTicks'] and t['nextNeutralTick']==total+1, aid+' complete action duration')
    check(t['activeFrames']==[v['startup'],v['startup']+v['active']-1], aid+' active range')
    check(t['recoveryFrames']==[v['startup']+v['active'],total], aid+' recovery range')
    if t['counterApplies']:
        check(t['blockAdvantageFirstActive']==v['blockstun']-(v['active']-1+v['recovery']), aid+' first active block advantage')
        check(t['blockAdvantageLastActive']==v['blockstun']-v['recovery'], aid+' last active block advantage')
    check(t['counterTotalFreeze']==v['counterFreezeFrames'], aid+' total CH freeze consistency')
    check(t['counterExtraHeldTicks']==math.ceil(v['counterSlowFrames']/2), aid+' CH held-tick count')
    hit=a['hitboxTimeline']['keys']
    if hit:
        timeline(hit,v['active'],aid+' active-relative hit keys')
        check(all(k['hit']==1 for k in hit), aid+' single contact group')
    for k in hit:
        check(all(box_ok(b) for b in k['boxes']), aid+' valid attack boxes')
    timeline(a['hurtboxTimeline']['keys'],total,aid+' hurt timeline bounds')
    for k in a['hurtboxTimeline']['keys']:
        check(all(box_ok(b) for b in k['boxes'].values()), aid+' valid anatomy boxes')
    check(all(box_ok(b) for key,b in a['pushbox'].items() if key in ('ground','air')), aid+' valid push boxes')
    if a.get('pushboxTimeline'):
        timeline(a['pushboxTimeline']['keys'],total,aid+' push keys')
        check(all(box_ok(k['box']) for k in a['pushboxTimeline']['keys']), aid+' push-key rectangles')
    for track in a['movement']['rootTrack']:
        check(1<=track['first']<=track['last']<=total, aid+' root track bounds')
    for key in ['normalTargets','specialTargets','followTargets','bleedGrabTargets']:
        check(all(target in by for target in a['cancels'][key]), aid+' legal route IDs '+key)
    pose_ticks=[k['frame'] for k in a['animation']['keys']]
    check(pose_ticks==sorted(set(pose_ticks)) and pose_ticks[0]==1 and pose_ticks[-1]==total, aid+' complete pose schedule')
    check((ROOT/f"geometry/{a['slot']:02d}.svg").is_file(), aid+' geometry sheet exists')

check('2S' not in by['2K']['cancels']['normalTargets'], 'no 2K→2S route')
check('5S' in by['c.S']['cancels']['normalTargets'], 'c.S→f.S route present')
check(by['5S']['cancels']['jumpCondition']=='none' and by['5S']['schema22Scalars']['jumpCancel']==0, 'f.S remains grounded')
check(by['5S']['schema22Scalars']['proximityRange']==9000 and by['c.S']['schema22Scalars']['reach']==7200, 'selected c.S geometry/proximity')
check(by['5D']['wound']['advantage']==0 and by['5D']['wound']['releaseCenterGap']==12000, 'Wound +0 / 120px reset')
check(by['5D']['wound']['actorPostReleaseTicks']==by['5D']['wound']['victimPostReleaseTicks']==0, 'Wound equal release')
for aid in ['4P+K','6P+K','236D','214D']:
    c=by[aid]['capture']
    check(c['victimPostReleaseTicks']-c['actorPostReleaseTicks']==c['advantage']==2, aid+' +2 capture release')
for aid in ['236D','214D']:
    a=by[aid];c=a['capture']
    check(sum((k['last']-k['first']+1)*k['dx'] for k in a['movement']['rootTrack'])==18000, aid+' finite 180px travel')
    check(c['jumpFailureLatch']['enabled'] and c['jumpFailureLatch']['from']=='action acceptance', aid+' whole-attempt jump latch')
    check(c['releaseCenterGap']==17000 and c['localRangeBeyondPushEdges']==2000, aid+' release/capture spacing')
check(spec['bleed']['duration']==420 and spec['bleed']['initialGrey']==20 and spec['bleed']['cap']==160, 'selected bleed values')
check(spec['movementContract']['stopSettle']['gameplayLockTicks']==0, 'interruptible stop overlay')
check(spec['movementContract']['inputPriorityExtension']['legalJumpBeforeGroundFD'] is True, 'jump before grounded FD')

mod_spec=importlib.util.spec_from_file_location('derived',ROOT/'tools/build_derived.py')
derived=importlib.util.module_from_spec(mod_spec);mod_spec.loader.exec_module(derived)
frames=[json.loads(line) for line in (ROOT/'FRAME_GEOMETRY.jsonl').read_text().splitlines()]
check(frames==derived.expanded_frames(), '894 expanded frames exactly match authoritative timelines')
check(len(frames)==894, 'total expanded frame count')
fm={(f['move'],f['frame']):f for f in frames}
for frame in range(3,13):check(set(fm[('6P',frame)]['hurtboxes'])=={'legs'}, '6P masked frame '+str(frame))
for frame in range(6,22):
    check(max(b[3] for b in fm[('214D',frame)]['hurtboxes'].values())==5200, 'Skim low body '+str(frame))
    check(fm[('236D',frame)]['lowCrush'], 'Vault low crush '+str(frame))
for aid in ['236D','214D']:
    for frame in [22,23,24,53]:
        check(fm[(aid,frame)]['pushbox'][3]==13800 and max(b[3] for b in fm[(aid,frame)]['hurtboxes'].values())>=14600, aid+' standing capture/recovery '+str(frame))

cs=load('CS_GEOMETRY_RESOLUTION.json')
check(by['c.S']['productionRig']==cs['productionRig'], 'registered c.S rig matches canonical')
check(by['c.S']['hitboxTimeline']==cs['hitboxTimeline'] and by['c.S']['hurtboxTimeline']==cs['hurtboxTimeline'], 'registered c.S geometry matches')
rig=cs['productionRig'];check(len(rig['perFrame'])==23, '23 registered c.S poses')
for f in rig['perFrame']:
    for hand in ['left','right']:
        nominal=2200 if hand=='left' else 4300
        length=math.dist(f[hand+'BladeHeel'],f[hand+'BladeTip'])
        check(abs(length-nominal)<1, f"c.S f{f['frame']} {hand} fixed blade length")
        for p,q in [('Shoulder','Elbow'),('Elbow','Wrist')]:
            check(abs(math.dist(f[hand+p],f[hand+q])-2400)<1.5, f"c.S f{f['frame']} {hand} fixed arm segment")
for svg in list((ROOT/'geometry').glob('*.svg'))+[ROOT/'CS_REGISTERED_ACTIVE_GUIDE.svg']:
    try:ET.parse(svg)
    except Exception as exc:check(False, str(svg.relative_to(ROOT))+' XML '+str(exc))

required=['START_HERE_CODEX.md','ENGINE_IMPLEMENTATION.md','ANIMATION_AND_ART.md','ALL_MOVES.md','BALANCE_AND_ROUTES.md','ACCEPTANCE_TESTS.md','CURRENT_CORE_CHECKS.md','VISUAL_REFERENCE_INDEX.json','VISUAL_REFERENCE_INDEX.md','FRAME_VIEWER.html','ACTION_ATLAS.html']
for name in required:check((ROOT/name).is_file(), 'required file '+name)
if (ROOT/'VISUAL_REFERENCE_INDEX.json').is_file():
    def paths(v):
        if isinstance(v,dict):
            for x in v.values():yield from paths(x)
        elif isinstance(v,list):
            for x in v:yield from paths(x)
        elif isinstance(v,str) and (v.startswith('references/') or re.match(r'^(?:geometry/|CS_).+\.(?:svg|json|png|jpg)$',v)):
            yield v
    for name in set(paths(load('VISUAL_REFERENCE_INDEX.json'))):check((ROOT/name).is_file(), 'reference '+name)

result={'scope':'static package integrity; not a gameplay implementation or playtest', 'status':'passed' if not errors else 'failed',
        'checks':checks, 'actions':len(actions),'disabledSlots':len(disabled),'scalarFieldsPerSlot':len(fields),
        'totalScalarValues':len(records)*len(fields),'expandedFrames':len(frames),'errors':errors}
print(json.dumps(result,indent=2))
if '--write' in sys.argv:(ROOT/'PACKAGE_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
sys.exit(bool(errors))
