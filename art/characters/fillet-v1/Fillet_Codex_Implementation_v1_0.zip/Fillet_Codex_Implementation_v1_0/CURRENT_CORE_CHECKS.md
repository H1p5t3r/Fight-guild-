# Executed current-core checks

**19 November 2026. Result: 37 scoped cases passed, zero failed assertions.** These checks exercise the final selected c.S/f.S through the existing native engine. They do not implement or validate the future Wound, paired capture, bleed-speed, exact anatomy, named-route or animation extensions.

## Inputs and scope

The probe compiles the unmodified packaged `baseline/current_source/core/fight.cpp`, `fight.h` and `combat_data.h` from **`cd8b0cedabfd508b0d82be2841d640e37928ef91`**. It loads the latest complete Workshop batch, SHA-256 `694db863a698510ddbedb8fb2ffc1ac20d7c9809be5994da36b503f2b1801510`, then overlays only final c.S/f.S scalar values, their exact native-compatible hitbox tracks, their three-phase compatibility hurt profiles, and Fillet attack friction90. The final source specification read for this run has SHA-256 `1cf575832c5b08c8a379e14690b0a06edd4da87e3b7ab00ff547b9be37b907d5`; a later metadata-only rewrite can change that file hash without changing these preserved input records.

Both attacks begin through real S input. The current upstream c.S→f.S proximity bypass is exercised directly: **no temporary bypass, dispatch patch or core modification** is used. Position/meter setup uses the preview placement API only. The target is current Shark. The complete other-character batch is loaded unchanged.

The final c.S has7/5/12 timing,44 damage,17 blockstun,6px ordinary block push,72px tip and90px neutral proximity. Its first-active rectangles are `[60,64,72,106]` and `[60,102,72,130]` pixels. f.S remains9/3/18,40 damage,16 blockstun,10px block push and125px initial tip. Entry inertia is65%/60%; this run's fixtures start stationary.

The new standing body appears in the loaded c.S/f.S compatibility hurt profiles, but the current engine cannot execute the final absolute per-frame anatomy or new locomotion body selection. No claim about their defensive correctness follows from this probe. It also does not implement per-frame pushbox extensions, new command slots, Up/FD priority, manual tech or paired clocks. Those remain required implementation acceptance cases.

## Observed results

The37 cases comprise29 route/buffer scenarios and8 neutral selection checks. Two route cases intentionally supply expired inputs; their expected lack of f.S is a passing result.

| Check | Observed result |
|---|---|
| Neutral S boundary |90.00px selects c.S;90.01px selects f.S. Passed both facings and both player indices. |
| Immediate c.S→f.S |c.S first contacts on absolute action7; f.S starts on first unfrozen tick and contacts on its action9. |
| Contact interval |9 unfrozen ticks,17 world ticks including c.S's8 hitstop. |
| Delayed cancels |Every completed c.S frame7…15 preserves blockstun. Frame16/17 contact occurs with zero prior stun, leaving one/two actionable ticks. |
| Normal hit |44+32=76 total; second hit retains the expected82% effective scaling. Earliest and latest tested cancel positions combo. |
| Input during hitstop |A one-frame S press1 or4 ticks after contact expires. A press5 or8 ticks after contact survives and starts f.S on the first unfrozen tick. |
| Mirroring/index/wall |The selected62px block/FD route gives the same timing and separation in both facings, both player indices and both tested corner directions. |

The defender holds down-back for ordinary block and down-back plus FD for FD. This avoids back-walking during c.S startup and isolates authored pushback. Distances are root-center separation:

| Starting separation | Guard | After c.S | After f.S |
|---:|---|---:|---:|
|62px |Ordinary |68px |78px |
|62px |FD |80px |110px |
|90px |Ordinary |96px |106px |
|90px |FD |108px |138px |

All listed contacts occur first active. Corner62px cases retain the same final gaps through the current block-push transfer. This confirms the compact selected c.S and existing f.S maintain the intended near/proximity-boundary route in these fixtures. It is not a whole-cast, late-active, movement-entry, grab-reach or balance guarantee. Late-gap defensive options and new Wound windows were not added to this run.

## Reproduction

`validation/current_core_checks/` contains the portable C++ probe, generated latest-batch and selected-action headers, captured input metadata/source hashes, raw37-case JSONL, validator and result summary. All inputs needed for this exact check are preserved. Run from the package root:

```bash
python validation/current_core_checks/build_headers.py --package .
g++ -std=c++17 -O0 -Ibaseline/current_source/core -Ivalidation/current_core_checks validation/current_core_checks/current_core_probe.cpp baseline/current_source/core/fight.cpp -o /tmp/fillet-current-core-probe
/tmp/fillet-current-core-probe > validation/current_core_checks/results.jsonl
python validation/current_core_checks/validate_results.py
```

The generated header hashes at execution were `333380cee67e950dbeec493fa1d911c77fe876204988c67806e5c655d692fecd` for `current_batch.h` and `df9e51088dd3b60cace964418c41aa2e9127d36b13fd1cace48ee642119ad2fb` for `selected.h`. The portable header generator was re-run and produced identical headers. The validator checks selection, first-active timing, freeze duration, guard continuity, exact block/FD displacement, ordinary damage and expected buffer expiry.

`ENGINE_IMPLEMENTATION.md` and `ACCEPTANCE_TESTS.md` now state the final standing reference envelope explicitly: legs `[-5400,0,6000,6200]`, torso/arms `[-3600,5200,3500,11800]`, head `[500,11800,3200,14600]`. They keep that hurt envelope separate from the2800-unit push half-width and preserve distinct crouch/air/reaction profiles. Their c.S selection boundary, latest source pin and existing-versus-new feature descriptions match this run.
