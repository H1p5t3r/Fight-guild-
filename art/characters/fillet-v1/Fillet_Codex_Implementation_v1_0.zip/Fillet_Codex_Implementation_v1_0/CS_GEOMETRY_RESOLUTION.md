# Final c.S geometry and production-path resolution

**Selected for Codex implementation · 19 November 2026**

The user has authorized completing Fillet’s full moveset through final design decisions. This resolution preserves the accepted **7f startup / +1 first-active block / 6px block push**, the refined **short-LEFT reverse-grip rising cut**, and the long RIGHT knife reserved for f.S. Exact coordinates below are the selected handoff target, with no further pose-by-pose approval gate. They are not a claim that every coordinate was individually user-approved or native-engine tested.

## Selected action contract

| Property | Final target |
|---|---:|
| Startup / active / recovery | **7 / 5 / 12** |
| First active / last active | **frames7 / 11** |
| Final recovery / next actionable | **frames23 / 24** |
| Damage / hitstun / blockstun | **44 / 24 / 17** |
| First-active block advantage | **+1**, since17−(4+12)=1 |
| Last-active block advantage, when that key connects | **+5**, since17−12=5 |
| Block push | **6px** |
| Hit level / hit groups | Mid / one group, one hit maximum |
| Short LEFT steel | **22px nominal**, fixed reverse-grip geometry |
| Run entry inertia / attack friction | **65% / 0.9px per tick²**, unchanged |
| Authored root advance/travel | **0** in every phase |
| f.S→c.S proximity threshold | **90px center distance**, replacing105px |

Keep all other central final-moveset damage/counter/cancel policies unless that master explicitly supersedes them. Preserve the planned c.S→f.S named route. The new body production drawing extends the attacking arm farther than the concept image; the concept supplies approved identity and motion direction, not literal game-space registration.

## Exact active and arm-hurt timeline

World-pixel rectangles use **[left,bottom,right,top]**. Multiply by100 for raw core data. Hit-key frames are active-relative; hurt frames are absolute. All attack rectangles belong to the same hit group.

| Action frame | Active key | Attack rectangles | Anatomical arm extension |
|---|---:|---|---|
| 7 | 1 | [60, 64, 72, 106]; [60, 102, 72, 130] | [20, 81, 64, 134] |
| 8 | 2 | [60, 106, 72, 130] | [20, 103, 64, 134] |
| 9 | 3 | [59, 105, 72, 130] | [20, 103, 64, 134] |
| 10 | 4 | [58, 103, 71, 129] | [20, 100, 63, 133] |
| 11 | 5 | [56, 100, 70, 127] | [20, 97, 62, 131] |

**First-active sweep is real authored motion:** at the end of frame6, the short blade heel is **(62,86)** and tip **(70,65.51)**. By the end of frame7, the heel is **(62,128)** and tip **(70,107.51)**. The point remains below the hand while the whole knife cuts upward. The first two rectangles cover that swept path with small conservative padding; they are not an invisible long knife or a second strike. The maximum selected attack reach is72px, while the physical tip reaches70px.

Later keys cover the high blade and its settling motion. **Only first-active includes the low portion of the rising sweep.** Later high keys can miss low-profile crouchers; this is intentional and visible. The first-active geometry contacts every stationary standing/crouching baseline pose in the selector’s legal range. This does not guarantee a hit against movement, jumping or invulnerability during startup.

The JSON supplies every frame1–23, including exact bones, fixed blade polygon, hand/grip/heel/tip coordinates, attack rectangles and anatomical boxes. It also supplies conservative phase fallbacks and a complete replacement move patch. The legacy scalar envelope is **[56,64,72,130]** across all active ticks, yielding `hitboxBack=5600,bottom=6400,reach=7200,height=6600`; it must not replace the detailed timeline with a persistent full-height hitbox.

## Production skeleton and fixed weapons

Both upper arms and forearms are **24px**. The left shoulder is **(24,107)**. Critical left wrist keys are:

| Frame | Left wrist | Blade heel | Blade tip |
|---|---|---|---|
| 1 | (32,115) | (35,113) | (43,92.51) |
| 3 | (36,90) | (39,88) | (47,67.51) |
| 5 | (52,88) | (55,86) | (63,65.51) |
| 6 | (59,88) | (62,86) | (70,65.51) |
| 7–8 | (59,130) | (62,128) | (70,107.51) |
| 9 | (58,129) | (61,127) | (69,106.51) |
| 10 | (57,127) | (60,125) | (68,104.51) |
| 11 | (55,124) | (58,122) | (66,101.51) |
| 12 | (50,120) | (53,118) | (61,97.51) |
| 17 | (36,113) | (39,111) | (47,90.51) |
| 23 | (32,115) | (35,113) | (43,92.51) |

Interpolate wrist keys per actor tick and solve the elbow with the two24px segments using the same bend branch. Exact integer joint results are in the JSON. The short blade uses a fixed heel-to-tip vector **(8,−20.49)**, approximately22px after hundredth-pixel quantization; neither blade length nor grip changes between keys. The right blade remains held low and passive, with nominal43px steel. Mirror the complete rig for facing left without exchanging anatomical hand ownership.

The neutral-production feet remain planted at **(−43,0)** and **(44,0)**. Pelvis is(0,74), neck(18,119), head center(19,133); the posed head envelope reaches146px. No drawing-root lunge is added. A running entry follows the existing65% physical carry and its friction; the support-foot phase can inherit the run without inserting an additional preparatory step.

The old generic body fit was too narrow for the wide stance and trailing arm. This move’s selected base anatomical profiles are:

| Region | Local world-pixel rectangle |
|---|---|
| legs | `[-54, 0, 60, 62]` |
| torsoArms | `[-36, 52, 35, 118]` |
| head | `[5, 118, 32, 146]` |

The fourth region is the per-frame attacking-arm extension. It includes glove/body movement, including the traversed arm corridor on frame7, and **excludes steel and trails**. The standing pushbox stays **[−28,0,28,138]**. Recovery continues to expose the retracting arm exactly as specified; frame24 returns to the appropriate locomotion/ready profile.

## Proximity verification

The exact pinned manifest/collision conversion was reproduced, including outward integer rounding. Across **21 standing/idle and crouching pose variants**, every raw integer center separation from each pair’s legal ground push distance through90px was checked: **66,021 distance checks**, all with strictly positive intersection area on the first active tick. The limiting outer boundary is **Hammer crouch at97.17px**, leaving **7.17px** beyond the selected90px threshold. Mirroring preserves these intersections.

Root confirmed neutral anatomy is unchanged through `cd8b0cedabfd508b0d82be2841d640e37928ef91`; the JSON preserves the exact audited file hashes. This is static geometry verification, not execution of the latest core. Codex must still verify actual input routing, movement during startup, block advantage, hitstop, cancellation and rollback. The selector must not stay105px after this reach change.

## f.S at125px: accepted production framework

A43px long RIGHT blade can support125px reach with an anatomical arm. The needed **80–82px is the hand/heel position from the root, not an80px arm bone**. A concrete horizontal layout is shoulder(30,104), elbow(54,104), wrist(78,104), blade heel(82,104), tip(125,104):24px upper arm +24px forearm +4px grip offset +43px steel. Torso lean/rotation places the shoulder forward; no unlisted root lunge is needed.

The far slash must expose the actual extended forearm/glove through approximatelyx82–86. Weapon-only reach beyond the hand has no hurtbox. Retain its central startup/recovery risks and give it a separate right-hand contact/recovery silhouette. This establishes feasibility; the master f.S timeline remains the authoritative full attack specification.

## Deliverables and implementation

- `CS_GEOMETRY_RESOLUTION.json`: full replacement hit/hurt tracks, scalars, proximity patch, phase fallbacks,23 rig frames and detailed cast-check evidence.
- `CS_REGISTERED_ACTIVE_GUIDE.svg`: exact schematic of frame6 and active frames7–11; original raster artwork is unchanged.

Use a dedicated short-left c.S animation mapping. Do not reuse generic long-right S art, grow the knife, flatten all active keys to the legacy envelope, or preserve the old105px selector. The production path is a final selected target for implementation; no additional user review is required before integrating it with the complete package.
