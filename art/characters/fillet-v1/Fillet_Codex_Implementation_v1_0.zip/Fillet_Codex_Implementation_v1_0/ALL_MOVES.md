# Fillet — complete move specification

Selected v1.0 build data. Implement every enabled action. This is a readable projection of `FILLET_SPEC.json`; the JSON and `ENGINE_IMPLEMENTATION.md` define the exact behavior. `FINAL_MOVE_VALUES.json` contains all 138 scalar values for every one of the 47 stable slots, including the 21 explicitly disabled slots. `PROPERTY_REFERENCE.json` explains each scalar, units, applicability and inherited source behavior. No unlisted special effect is implied by an animation or by a donor reference.

## Conventions

60 simulation ticks per second. Raw coordinates use 100 units per pixel. Rectangles are `[left,bottom,right,top]`, local to the fighter root, facing right, with positive Y upward. Mirror X as `[-right,bottom,-left,top]`. Body rectangles below are complete records at each key; absent extension means absent. Hold a record until its next key. Strike keys are active-relative; all body, push, root and pose keys are absolute action frames.

Startup S names the first active frame. The complete whiff duration is S−1+A+R. Frame advantage is measured from first-active contact unless stated otherwise, excluding equal shared freeze. Later contact can improve advantage by the elapsed active frames. Counter freeze is the total shared freeze, followed by alternating defender slow ticks; it is not an additional freeze on top of ordinary hitstop. Capture/Wound success replaces the remaining ordinary action and uses its dedicated pair clocks.

Exact per-frame diagrams: `FRAME_VIEWER.html` and `ACTION_ATLAS.html`. Production posing, every locomotion/defense transition and both roles of every grab: `ANIMATION_AND_ART.md`. Visual donor provenance: `VISUAL_REFERENCE_INDEX.md`.

## Whole kit

| Input | Move | S/A/R | Damage | Block | Guard / contact | CH freeze/slow/extra stun |
| --- | --- | --- | --- | --- | --- | --- |
| 5P | Short check | 5/3/9 | 24 | -1 | mid | 9/0/4 |
| 5K | Step kick | 7/3/13 | 32 | -2 | mid | 9/0/4 |
| c.S | Inside cut | 7/5/12 | 44 | +1 | mid | 21/25/0 |
| f.S | Long knife | 9/3/18 | 40 | -4 | mid | 21/25/0 |
| 5Hs | Crosscut | 13/4/22 | 60 | -7 | mid | 31/35/0 |
| 2P | Low stance check | 5/2/10 | 20 | -1 | mid | 9/0/4 |
| 2K | Ankle check | 6/3/11 | 26 | -2 | low | 9/0/4 |
| 2S | Sweep | 12/4/23 | 42 | -8 | low | 21/25/0 |
| 2Hs | Rising scissors | 14/5/24 | 62 | -9 | mid | 31/35/0 |
| 6P | Shoulder guard cut | 9/4/20 | 34 | -8 | mid | 21/25/0 |
| 6Hs | Chasing cleave | 18/4/25 | 72 | -8 | mid | 31/35/0 |
| j.P | Air check | 5/3/10 | 22 | -2 | overhead | 9/0/4 |
| j.K | Descending kick | 7/4/13 | 30 | -3 | overhead | 9/0/4 |
| j.S | Falling knife | 10/4/17 | 42 | -4 | overhead | 21/25/0 |
| j.Hs | Turning scissors | 13/5/22 | 55 | -8 | overhead | 31/35/0 |
| 236P | Needle check | 12/3/16 | 34 | -4 | mid | 10/0/3 |
| 236S | Opening cut | 9/3/18 | 28 | -3 | mid | 10/0/3 |
| 236S > 6S | Crown cut | 21/3/22 | 48 | -6 | overhead | 18/0/4 |
| 236S > 2S | Heel cut | 16/3/24 | 40 | -9 | low | 16/0/4 |
| 236K | Passing cut | 27/3/24 | 36 | -10 | mid | 18/16/4 |
| 623Hs | Rising carve | 11/5/29 | 64 | -16 | mid | 20/16/4 |
| 4P+K | Back throw | 2/2/32 | 45; one health event at release | — | not blockable; legal grounded capture only | not a strike |
| 6P+K | Forward throw | 2/2/32 | 45; one health event at release | — | not blockable; legal grounded capture only | not a strike |
| D / 5D | Wound | 24/2/20 | 0 | — | does not contact standing/crouching/airborne targets | not a strike |
| 236D | Vault cashout | 22/2/30 | 55 + grey-life snapshot, cap160 grey; one health event at release | — | not blockable; legal grounded capture only | not a strike |
| 214D | Skim cashout | 22/2/30 | 55 + grey-life snapshot, cap160 grey; one health event at release | — | not blockable; legal grounded capture only | not a strike |

## Shared behavior

Ordinary strikes use one contact group, no armor, no guard point, no projectile, no general strike invulnerability, no whiff cancel and no RC. Explicit exceptions are fully specified below: 6P masks upper anatomy on frames 3–12; Vault low-crush lasts 6–21; Skim evasion is geometric on 6–21. These protections end before command capture. Fillet has no invulnerable reversal. Ordinary attack recovery is throwable unless a separate protected state applies.

Entry inertia is sampled once from eligible current/carry velocity; signed division truncates toward zero. Apply authored travel separately, then 90 raw units of attack friction per advancing actor tick. Do not reapply movement bonuses during a chain. Source contact hitstop holds the resolved pose and roots. A legal cancel replaces the old animation immediately, without its recovery or a transition tax.

Normal-route and special-route lists are exact allowlists. Scalar route masks are compatibility metadata, not permission to add extra destinations. Empty list means no route. A contact-gated move cannot cancel on whiff. Bleed-grab routes need owned bleed and at least five completed attacker action ticks since the last contact in the permitted special/follow window. `2K→2S` is excluded. Neutral S uses c.S at ≤90px center spacing; legal c.S→S selects f.S regardless of that selector.

### Bleed

```json
{
  "duration": 420,
  "clock": "unfrozen shared simulation ticks after Wound pair releases; no hit/block refresh; zero on timeout",
  "initialGrey": 20,
  "tickGrey": 3,
  "tickInterval": 30,
  "blockGreyPercent": 20,
  "blockGreyRounding": "floor(base damage * 20 / 100), after successful ordinary block only",
  "FDblockGrey": 0,
  "cap": 160,
  "normalHitRefresh": false,
  "normalHitExtraGrey": 0,
  "realHealthDamageBeforeCashout": 0,
  "groundMovementPercent": 115,
  "airDashPercent": 110,
  "scales": [
    "walk",
    "backwalk",
    "run cap",
    "run acceleration",
    "ground step/backdash speeds",
    "forward air dash speed"
  ],
  "doesNotScale": [
    "startup/active/recovery",
    "attack root tracks",
    "attack inertia percentage",
    "friction",
    "jump vertical speed",
    "gravity",
    "jump horizontal speed",
    "pushback",
    "grab reach"
  ],
  "cleanup": [
    "owner suffers an unblocked strike/throw",
    "target or owner KO",
    "round reset",
    "duration reaches zero",
    "successful command capture"
  ],
  "cashout": "snapshot existing grey and consume status at confirmed command capture; release deals55+snapshot; no second application; normal throws do not cash out",
  "greyClamp": "min(160, max(0, target current health - 1)); re-clamp on application, periodic/block growth and every target health change"
}
```

### Ground normal-throw tech

```json
{
  "status": "selected shared dependency; apply six-unfrozen-tick pre-commit gate to other characters’ ground normal throws while preserving their authored payload",
  "window": "C1–C6 shared unfrozen pair ticks; C0 simultaneous normal-throw clash remains",
  "input": "fresh valid P+K chord",
  "sharedFreeze": 6,
  "equalRecoveryTicks": 12,
  "releaseCenterGap": 12000,
  "advantage": 0,
  "throwGraceBothOnUnlock": 5,
  "sideSwitch": false,
  "damage": 0,
  "statusChange": false,
  "otherCharactersAdapter": "Pay authored capture hitstop once. Check fresh tech at C1–C6 before C6 commit; on failure apply their existing throw payload/side-swap/recovery without second capture freeze. Air, command and stance throws do not gain this late-tech window."
}
```

## 01. 5P — Short check

Fast standing interruption; short knife and exposed forearm.

**Stable slot:** 0. **Input:** 5P. **Animation clip:** `fillet_5p`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 5 / 3 / 9 |
| Absolute active frames | 5–7 |
| Recovery / next neutral | 8–16; next neutral 17 |
| Block advantage first / last active | -1 / +1 |
| Counter | Total shared freeze 9; slow 0 (0 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 6 |
| Entry inertia | 40% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 24 |
| `hitstun` | 14 |
| `blockstun` | 10 |
| `hitstop` | 6 |
| `hitLevel` | 0 |
| `pushback` | 1200 |
| `airPushback` | 1600 |
| `blockPushback` | 600 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 1 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 9 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 80 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 5 |
| `normalCancelEnd` | 13 |
| `specialCancelStart` | 5 |
| `specialCancelEnd` | 13 |
| `jumpCancelStart` | 5 |
| `jumpCancelEnd` | 11 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "5P",
      "2P",
      "5K",
      "2K",
      "6P"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 40,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 192,
    "nominalDefenderOnHit": 96,
    "nominalAttackerOnBlock": 96,
    "nominalDefenderOnOrdinaryBlock": 72,
    "defenderOnFDBlock": 0,
    "FDContactCost": 250,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 80,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 5 | 1 | [[2300, 8000, 7000, 10500]] |
| 3 | 7 | 1 | [[2300, 8000, 6200, 10500]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 3 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1800,7600,5700,10800]} |
| 5 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1800,7600,5700,10800]} |
| 8 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1800,7600,4200,10800]} |
| 11 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 2,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 4,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 5,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 7,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 8,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 11,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 16,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From Stalker idle, lift only the left elbow out of the existing high-hand guard. From a walk/run, preserve the incoming support foot and let the torso settle over it; do not insert a preparatory step. A crouching source must select the legal standing action first; do not silently turn 2P into 5P.",
    "support_and_weight": "Left foot normally supports the short check, with the right heel light. A run-entry variant keeps the current planted foot and uses the same compact upper-body shape.",
    "knife_assignment": "Short LEFT knife makes the small forward cut. Long RIGHT knife stays low beside the rear hip, fully visible as a separate longer silhouette.",
    "staging": {
      "anticipation": "Left shoulder draws a little inward; the head remains above the guard and the right hand stays quiet.",
      "contact": "Present a compact horizontal left-hand cut through the authored chest-height corridor, with the left forearm visibly extending ahead of the torso.",
      "follow_through": "Finish with the left elbow still in front of the ribs; do not turn the check into a full cross-body swing.",
      "retraction": "Bring the left hand back along the same short path, elbow first, while the right knife remains in its low ready position."
    },
    "geometry_and_visible_weakness": "The extended forearm must remain visible while its hurt extension persists. Neither the longer right blade nor a decorative trail may imply additional reach.",
    "legal_cancel_bridge": "Use the left-hand return as the hinge: drop the hips for 2P/2K, leave space for the right-leg 5K, or close the left shoulder into 6P. Special cancels use their own entry pose immediately when legal. No Wound or bleed-grab bridge is authored from this action.",
    "whiff_vs_contact": "Whiff passes cleanly through and returns without a second flick. Hit/block holds only the declared contact freeze; block uses a tighter wrist recoil, while the target's hit reaction supplies the impact distinction.",
    "facing_authorship": "On the reverse-facing sheet, keep the short blade attached to the left glove even when that arm becomes farther from camera; preserve a small gap between both knife silhouettes.",
    "action_name": "Short check",
    "source_reference_id": "chipp_5p",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "5P",
        "2P",
        "5K",
        "2K",
        "6P"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/00.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 02. 5K — Step kick

Midrange foot check and light confirm; deliberate recovery.

**Stable slot:** 1. **Input:** 5K. **Animation clip:** `fillet_5k`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 7 / 3 / 13 |
| Absolute active frames | 7–9 |
| Recovery / next neutral | 10–22; next neutral 23 |
| Block advantage first / last active | -2 / +0 |
| Counter | Total shared freeze 9; slow 0 (0 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 6 |
| Entry inertia | 60% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 32 |
| `hitstun` | 18 |
| `blockstun` | 13 |
| `hitstop` | 6 |
| `hitLevel` | 0 |
| `pushback` | 1600 |
| `airPushback` | 2000 |
| `blockPushback` | 800 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 1 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 9 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 7 |
| `normalCancelEnd` | 15 |
| `specialCancelStart` | 7 |
| `specialCancelEnd` | 15 |
| `jumpCancelStart` | 7 |
| `jumpCancelEnd` | 13 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "6P",
      "6Hs"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [
      "236D",
      "214D"
    ],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded",
    "bleedGrabWindow": [
      7,
      15
    ],
    "bleedGrabPriority": "dedicated authoritative route overrides legacy Throw-destination rejection and source specialCancel only for these listed command targets; requires actual hit/block, five elapsed attacker ticks, owned bleed and the listed window. Ordinary normal-throw cancels remain forbidden."
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 60,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 256,
    "nominalDefenderOnHit": 128,
    "nominalAttackerOnBlock": 128,
    "nominalDefenderOnOrdinaryBlock": 96,
    "defenderOnFDBlock": 0,
    "FDContactCost": 300,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 7 | 1 | [[2800, 2300, 9400, 6000]] |
| 3 | 9 | 1 | [[2800, 2300, 8600, 6000]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 5 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,2100,8800,6400]} |
| 7 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,2100,8800,6400]} |
| 10 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,2100,7300,6400]} |
| 15 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 3,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 6,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 7,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 9,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 10,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 15,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 22,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From idle, collect the right knee under the torso. From a run, retain the support phase and route the next visible right-leg extension into the kick rather than adding a new stride. A low source may rise only within the existing legal entry, with no extra crouch-to-stand delay.",
    "support_and_weight": "Left foot is the planted support; the pelvis sits over it while the right leg extends forward. Keep the torso upright enough to preserve the standing silhouette.",
    "knife_assignment": "Neither knife attacks: long RIGHT stays outside the right hip with its tip trailing; short LEFT stays near the upper chest. Separate the blade tips from the kicking boot.",
    "staging": {
      "anticipation": "Raise the right knee in a compact fold; the left elbow opens slightly as a counterweight.",
      "contact": "Extend the right boot into the low-middle corridor, keeping the knee and shin readable as one vulnerable limb.",
      "follow_through": "Hold the hip behind the foot rather than translating the root farther forward. The kicking leg remains out through the authored extension.",
      "retraction": "Fold the right knee back before setting the boot into Stalker; the torso settles over the left foot instead of bouncing upward."
    },
    "geometry_and_visible_weakness": "The boot is the strike source. Do not light the knives as active or hide the extended shin during recovery.",
    "legal_cancel_bridge": "The recoiling knee can settle into 6P or let the torso coil for 6Hs. Approved specials start from that same compact hip position. The bleed-grab bridge waits for its own legal cancel gate, then plants for the hop or lowers for the skim; no ground dash-cancel is implied.",
    "whiff_vs_contact": "On whiff, show the extended boot finding no resistance and a deliberate knee fold. Contact freeze compresses the ankle/hip silhouette subtly; it does not shorten recovery or make the knives strike.",
    "facing_authorship": "Author the right boot consistently in both facings; swapping which leg kicks would break the weapon-side counterbalance.",
    "action_name": "Step kick",
    "source_reference_id": "giovanna_5k",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "6P",
        "6Hs"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [
        "236D",
        "214D"
      ],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/01.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 03. c.S — Inside cut

Close pressure anchor, +1 on first-active block; opens f.S route.

**Stable slot:** 32. **Input:** c.S. **Animation clip:** `fillet_c_s`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 7 / 5 / 12 |
| Absolute active frames | 7–11 |
| Recovery / next neutral | 12–23; next neutral 24 |
| Block advantage first / last active | +1 / +5 |
| Counter | Total shared freeze 21; slow 25 (13 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 8 |
| Entry inertia | 65% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 44 |
| `hitstun` | 24 |
| `blockstun` | 17 |
| `hitstop` | 8 |
| `hitLevel` | 0 |
| `pushback` | 1600 |
| `airPushback` | 2000 |
| `blockPushback` | 600 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 21 |
| `counterSlowFrames` | 25 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 7 |
| `normalCancelEnd` | 17 |
| `specialCancelStart` | 7 |
| `specialCancelEnd` | 17 |
| `jumpCancelStart` | 7 |
| `jumpCancelEnd` | 15 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 9000 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "5S",
      "5Hs",
      "2Hs",
      "6Hs",
      "2S"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_or_block",
    "jumpCondition": "hit_or_block",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [
      "236D",
      "214D"
    ],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded",
    "bleedGrabWindow": [
      7,
      17
    ],
    "bleedGrabPriority": "dedicated authoritative route overrides legacy Throw-destination rejection and source specialCancel only for these listed command targets; requires actual hit/block, five elapsed attacker ticks, owned bleed and the listed window. Ordinary normal-throw cancels remain forbidden."
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 65,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 352,
    "nominalDefenderOnHit": 176,
    "nominalAttackerOnBlock": 176,
    "nominalDefenderOnOrdinaryBlock": 132,
    "defenderOnFDBlock": 0,
    "FDContactCost": 350,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 7 | 1 | [[6000, 6400, 7200, 10600], [6000, 10200, 7200, 13000]] |
| 2 | 8 | 1 | [[6000, 10600, 7200, 13000]] |
| 3 | 9 | 1 | [[5900, 10500, 7200, 13000]] |
| 4 | 10 | 1 | [[5800, 10300, 7100, 12900]] |
| 5 | 11 | 1 | [[5600, 10000, 7000, 12700]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,9000,4900,11900]} |
| 2 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1500,7900,4900,11900]} |
| 3 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[800,7900,4100,11100]} |
| 4 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[800,7900,4900,11100]} |
| 5 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1600,7900,5700,11100]} |
| 6 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,7900,6400,11100]} |
| 7 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8100,6400,13400]} |
| 8 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,10300,6400,13400]} |
| 9 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,10300,6400,13400]} |
| 10 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,10000,6300,13300]} |
| 11 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,9700,6200,13100]} |
| 12 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,9200,6000,12800]} |
| 13 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,9000,5500,12400]} |
| 14 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8900,5300,12300]} |
| 15 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8700,5000,12200]} |
| 16 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8600,4700,12000]} |
| 17 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8500,4600,11900]} |
| 18 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8500,4500,11800]} |
| 19 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8500,4600,11800]} |
| 20 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8600,4700,11800]} |
| 21 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8700,4800,11900]} |
| 22 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8800,4800,11900]} |
| 23 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,8900,4900,11900]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 3,
      "label": "anticipation",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 5,
      "label": "anticipation",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 6,
      "label": "pre_contact",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 7,
      "label": "active",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 8,
      "label": "active_path",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 9,
      "label": "active_path",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 10,
      "label": "active_path",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 11,
      "label": "active_path",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 12,
      "label": "recovery",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 17,
      "label": "retract",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    },
    {
      "frame": 23,
      "label": "last_locked",
      "guide": "Use this exact actor-frame pose from productionRig; paired/contact holds never add action frames."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "status": "selected production motion; use exact rig/path in CS_GEOMETRY_RESOLUTION.json",
    "entry": "Preserve the incoming planted support foot and authored carry. Use the registered forward left-arm path; no extra root lunge or startup delay.",
    "knife_assignment": "Short anatomical LEFT knife in a fixed reverse grip performs the rising cut. Long RIGHT knife remains low and passive for f.S.",
    "staging": {
      "anticipation": "Small inward wrist load then extend to the exact end-frame6 path anchor.",
      "contact": "Sweep the fixed22px short blade upward along the authored frame6-to7 path. Frames8–11 hold/retract only the high blade path; do not leave damaging low trails.",
      "follow_through": "Keep grip and blade length fixed. Respect the exact arm envelope and shrinking per-frame strike keys.",
      "retraction": "Fold left forearm back into guard during the selected recovery keys; keep both feet grounded."
    },
    "legal_cancel_bridge": "A legal c.S to f.S cancel starts the low-ready RIGHT-arm extension immediately. Do not finish left-arm recovery first or add a transition frame.",
    "geometry_and_visible_weakness": "The final72px tip and90px neutral selector replace old85px/105px values. Use the complete refitted body/arm timeline. The concept sheet supplies identity and motion direction; the registered rig supplies production coordinates.",
    "whiff_vs_contact": "Only declared hitstop holds the current key. Whiff continues the same23-tick action without an impact hold.",
    "facing_authorship": "Mirror the whole registered rig and collision together; preserve anatomical LEFT short / RIGHT long knife ownership."
  }
}
```

Geometry sheet: `geometry/32.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 04. f.S — Long knife

Primary medium-speed poke and close-to-far pressure continuation.

**Stable slot:** 2. **Input:** f.S. **Animation clip:** `fillet_5s`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 9 / 3 / 18 |
| Absolute active frames | 9–11 |
| Recovery / next neutral | 12–29; next neutral 30 |
| Block advantage first / last active | -4 / -2 |
| Counter | Total shared freeze 21; slow 25 (13 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 8 |
| Entry inertia | 60% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 40 |
| `hitstun` | 22 |
| `blockstun` | 16 |
| `hitstop` | 8 |
| `hitLevel` | 0 |
| `pushback` | 2200 |
| `airPushback` | 2600 |
| `blockPushback` | 1000 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 21 |
| `counterSlowFrames` | 25 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 9 |
| `normalCancelEnd` | 17 |
| `specialCancelStart` | 9 |
| `specialCancelEnd` | 17 |
| `jumpCancelStart` | 9 |
| `jumpCancelEnd` | 15 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | 32 |
| `proximityRange` | 9000 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "5Hs",
      "2Hs",
      "6Hs"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [
      "236D",
      "214D"
    ],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded",
    "bleedGrabWindow": [
      9,
      17
    ],
    "bleedGrabPriority": "dedicated authoritative route overrides legacy Throw-destination rejection and source specialCancel only for these listed command targets; requires actual hit/block, five elapsed attacker ticks, owned bleed and the listed window. Ordinary normal-throw cancels remain forbidden."
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 60,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 320,
    "nominalDefenderOnHit": 160,
    "nominalAttackerOnBlock": 160,
    "nominalDefenderOnOrdinaryBlock": 120,
    "defenderOnFDBlock": 0,
    "FDContactCost": 350,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 9 | 1 | [[3100, 6600, 12500, 9900]] |
| 3 | 11 | 1 | [[3100, 6600, 11700, 9900]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 7 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,6300,8000,10800]} |
| 9 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,6300,8000,10800]} |
| 12 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[2000,6300,6500,10800]} |
| 20 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 4,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 8,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 9,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 11,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 12,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 20,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 29,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From c.S, the short LEFT hand retracts while long RIGHT starts from low and ready. Preserve incoming support foot and remaining momentum. Extend the right shoulder/arm during this action’s own startup; no extra step or added startup.",
    "support_and_weight": "Left foot carries the forward reach; right heel releases slightly while the hips remain inside the body footprint.",
    "knife_assignment": "Long RIGHT knife owns the entire narrow forward corridor. Short LEFT stays near the sternum with its tip angled away from the right forearm.",
    "staging": {
      "anticipation": "Draw the right elbow back beside the waist, leaving a clear horizontal lane between the hands.",
      "contact": "Open the right shoulder and extend the long blade horizontally; keep the left hand visibly closer to the body so the two weapons have different jobs.",
      "follow_through": "Allow a small torso turn to finish the reach, then hold the exposed right forearm rather than instantly snapping it home.",
      "retraction": "Recover the right elbow first and then the wrist, returning the long blade to its low rear position."
    },
    "geometry_and_visible_weakness": "The blade can exceed the arm's hurt volume, but the arm must remain visibly exposed where authored. No root lunge, weapon stretch, or tip-length change may make this reach larger.",
    "legal_cancel_bridge": "The extended right hand can fold inward for 5Hs/2Hs/6Hs or enter the approved special startups. For a gated bleed grab, release the reaching shoulder into a left-forearm approach rather than changing the right knife into a grabbing hand.",
    "whiff_vs_contact": "Whiff emphasizes a long unsupported reach followed by a measured withdrawal. Contact uses the same line with declared hitstop; a block recoil is local to the wrist and shoulder.",
    "facing_authorship": "Reverse-facing art must preserve the long right blade's apparent length after foreshortening; do not substitute the short left blade merely because it is nearer camera.",
    "action_name": "Long knife",
    "source_reference_id": "chipp_fs",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "5Hs",
        "2Hs",
        "6Hs"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [
        "236D",
        "214D"
      ],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/02.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 05. 5Hs — Crosscut

Committed midrange reward and frame-trap threat; no free Wound.

**Stable slot:** 3. **Input:** 5Hs. **Animation clip:** `fillet_5hs`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 13 / 4 / 22 |
| Absolute active frames | 13–16 |
| Recovery / next neutral | 17–38; next neutral 39 |
| Block advantage first / last active | -7 / -4 |
| Counter | Total shared freeze 31; slow 35 (18 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 10 |
| Entry inertia | 50% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 60 |
| `hitstun` | 27 |
| `blockstun` | 18 |
| `hitstop` | 10 |
| `hitLevel` | 0 |
| `pushback` | 2800 |
| `airPushback` | 3200 |
| `blockPushback` | 1400 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 3 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 31 |
| `counterSlowFrames` | 35 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 13 |
| `normalCancelEnd` | 22 |
| `specialCancelStart` | 13 |
| `specialCancelEnd` | 22 |
| `jumpCancelStart` | 13 |
| `jumpCancelEnd` | 20 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "6Hs"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [
      "236D",
      "214D"
    ],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded",
    "bleedGrabWindow": [
      13,
      22
    ],
    "bleedGrabPriority": "dedicated authoritative route overrides legacy Throw-destination rejection and source specialCancel only for these listed command targets; requires actual hit/block, five elapsed attacker ticks, owned bleed and the listed window. Ordinary normal-throw cancels remain forbidden."
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 50,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 480,
    "nominalDefenderOnHit": 240,
    "nominalAttackerOnBlock": 240,
    "nominalDefenderOnOrdinaryBlock": 180,
    "defenderOnFDBlock": 0,
    "FDContactCost": 400,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 13 | 1 | [[2400, 3900, 11600, 10200], [1100, 9000, 7800, 13200]] |
| 4 | 16 | 1 | [[2400, 3900, 10800, 10200], [1100, 9000, 7000, 13200]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 11 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1300,4800,7500,12200]} |
| 13 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1300,4800,7500,12200]} |
| 17 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1300,4800,6000,12200]} |
| 27 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 6,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 12,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 13,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 16,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 17,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 27,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 38,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From idle/run, widen the upper-body preparation while retaining the grounded step already supplied by gameplay. From 5S, gather the extended right elbow inward; from c.S, carry its high finish into a crossing preparation.",
    "support_and_weight": "Left foot anchors the body while the right foot pivots under the rotating hips. Keep the stance broad enough to show commitment without adding root travel.",
    "knife_assignment": "Long RIGHT knife makes the larger lower/forward diagonal. Short LEFT makes the shorter upper diagonal; their silhouettes cross once but remain identifiable.",
    "staging": {
      "anticipation": "Separate both elbows to opposite sides of the torso, forming an open asymmetrical frame rather than two identical windups.",
      "contact": "Bring the two blade paths into a clear cross in front of Fillet. Read it as one heavy contact event, with the right weapon carrying the longer reach.",
      "follow_through": "Let the right shoulder finish forward and the left elbow finish high; hold that open torso shape through the exposed part of recovery.",
      "retraction": "Uncross the left hand upward first, then withdraw the long right blade low, so the weapons never pass through one another in the drawing."
    },
    "geometry_and_visible_weakness": "The crossed visual must not suggest two hit groups. Keep the chest and reaching forearm readable during the commitment; broad trails add no collision.",
    "legal_cancel_bridge": "Use the crossed finish as a coil for 6Hs or the permitted special entries. Gated bleed grabs gather the left forearm from the upper diagonal; the right hand keeps its blade throughout. No direct Wound transition.",
    "whiff_vs_contact": "Whiff carries the heavier torso turn farther through its local arc but follows the same authored root. On contact, hold the X silhouette for the defined freeze and avoid an extra finishing slash.",
    "facing_authorship": "In the reverse view, expose enough of the right wrist and blade spine to distinguish the long lower diagonal from the short left upper diagonal.",
    "action_name": "Crosscut",
    "source_reference_id": "chipp_5h",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "6Hs"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [
        "236D",
        "214D"
      ],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/03.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 06. 2P — Low stance check

Fast crouching mid; does not duplicate the low mix of 2K.

**Stable slot:** 4. **Input:** 2P. **Animation clip:** `fillet_2p`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 5 / 2 / 10 |
| Absolute active frames | 5–6 |
| Recovery / next neutral | 7–16; next neutral 17 |
| Block advantage first / last active | -1 / +0 |
| Counter | Total shared freeze 9; slow 0 (0 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 6 |
| Entry inertia | 35% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 20 |
| `hitstun` | 13 |
| `blockstun` | 10 |
| `hitstop` | 6 |
| `hitLevel` | 0 |
| `pushback` | 1000 |
| `airPushback` | 1400 |
| `blockPushback` | 500 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 1 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 9 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 80 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 5 |
| `normalCancelEnd` | 12 |
| `specialCancelStart` | 5 |
| `specialCancelEnd` | 12 |
| `jumpCancelStart` | 5 |
| `jumpCancelEnd` | 10 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "5P",
      "2P",
      "5K",
      "2K",
      "6P"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 35,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 160,
    "nominalDefenderOnHit": 80,
    "nominalAttackerOnBlock": 80,
    "nominalDefenderOnOrdinaryBlock": 60,
    "defenderOnFDBlock": 0,
    "FDContactCost": 250,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 80,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 5 | 1 | [[2000, 3400, 6500, 6000]] |
| 2 | 6 | 1 | [[2000, 3400, 5700, 6000]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |
| 3 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1300,3000,5600,6500]} |
| 5 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1300,3000,5600,6500]} |
| 7 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1300,3000,4100,6500]} |
| 11 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      8000
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 2,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 4,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 5,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 6,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 7,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 11,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 16,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From an existing crouch, begin with the hips already low. From idle/run, the first action drawing must fit the crouching profile immediately; preserve the support foot and compress over it rather than adding a standing transition.",
    "support_and_weight": "Weight stays mostly over the rear right foot with the left foot lightly bracing the low stance. Keep both boots near the body.",
    "knife_assignment": "Short LEFT knife performs the compact forward check at low torso height. Long RIGHT rests low and back without crossing the left forearm.",
    "staging": {
      "anticipation": "Draw the left elbow beside the bent knee while the head stays tucked above the forearm line.",
      "contact": "Send the short blade horizontally through the crouching mid corridor; the action is visually low in posture but is not an ankle-level low.",
      "follow_through": "Finish with only the left arm outside the crouching core, keeping the pelvis still.",
      "retraction": "Fold the left elbow beside the torso and return directly to the crouch hold; rise only if the next legal action requires it."
    },
    "geometry_and_visible_weakness": "The crouching mid must look different from the foot-based 2K. The exposed left forearm remains a visible challenge point.",
    "legal_cancel_bridge": "Stay low for repeated 2P/2K; lift through the existing startup when entering 5P/5K/6P or approved specials. Do not insert an extra idle frame or create a direct sweep/bleed-grab route.",
    "whiff_vs_contact": "Whiff is a small empty-space check. Contact slightly checks the left wrist during hitstop; there is no body launch, ground-cut trail or second knife action.",
    "facing_authorship": "Maintain the left-arm lead even when it is the far arm; the long right blade remains a low background silhouette.",
    "action_name": "Low stance check",
    "source_reference_id": "chipp_2p",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "5P",
        "2P",
        "5K",
        "2K",
        "6P"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/04.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 07. 2K — Ankle check

Fast low and special confirm. No assumed 2K to sweep gatling.

**Stable slot:** 5. **Input:** 2K. **Animation clip:** `fillet_2k`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 6 / 3 / 11 |
| Absolute active frames | 6–8 |
| Recovery / next neutral | 9–19; next neutral 20 |
| Block advantage first / last active | -2 / +0 |
| Counter | Total shared freeze 9; slow 0 (0 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 6 |
| Entry inertia | 45% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 26 |
| `hitstun` | 17 |
| `blockstun` | 11 |
| `hitstop` | 6 |
| `hitLevel` | 1 |
| `pushback` | 1300 |
| `airPushback` | 1700 |
| `blockPushback` | 700 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 1 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 9 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 80 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 6 |
| `normalCancelEnd` | 14 |
| `specialCancelStart` | 6 |
| `specialCancelEnd` | 14 |
| `jumpCancelStart` | 6 |
| `jumpCancelEnd` | 12 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "low",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "6P",
      "6Hs"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [
      "236D",
      "214D"
    ],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded",
    "bleedGrabWindow": [
      6,
      14
    ],
    "bleedGrabPriority": "dedicated authoritative route overrides legacy Throw-destination rejection and source specialCancel only for these listed command targets; requires actual hit/block, five elapsed attacker ticks, owned bleed and the listed window. Ordinary normal-throw cancels remain forbidden."
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 45,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 208,
    "nominalDefenderOnHit": 104,
    "nominalAttackerOnBlock": 104,
    "nominalDefenderOnOrdinaryBlock": 78,
    "defenderOnFDBlock": 0,
    "FDContactCost": 250,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 80,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 6 | 1 | [[2900, 200, 8800, 2900]] |
| 3 | 8 | 1 | [[2900, 200, 8000, 2900]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |
| 4 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1500,200,8300,3200]} |
| 6 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1500,200,8300,3200]} |
| 9 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1500,200,6800,3200]} |
| 13 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      8000
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 3,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 5,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 6,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 8,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 9,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 13,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 19,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From crouch, release the right leg from under the hips. From idle/run, drop directly into the authored crouching entry while preserving the current root motion; do not add a slide into range.",
    "support_and_weight": "The left foot and folded left leg support a compact low seat. The right heel/boot extends forward while the torso remains over the support.",
    "knife_assignment": "Both knives are held clear: short LEFT above the bent knee, long RIGHT near the rear hip with its edge outside the kicking-leg silhouette.",
    "staging": {
      "anticipation": "Pull the right knee inward enough to make the following low extension readable without a large body windup.",
      "contact": "Extend the right boot close to the floor through the low corridor. Keep the leg as a straight readable shape rather than a complete spinning sweep.",
      "follow_through": "Leave the right shin visible through the active finish, with the torso still compressed behind it.",
      "retraction": "Fold the right knee back under the body; keep the left foot planted until a legal next action takes over."
    },
    "geometry_and_visible_weakness": "Do not hide the extended lower leg or turn its recovery into a low-profile slide. The knives stay visually inactive.",
    "legal_cancel_bridge": "Bridge to 6P/6Hs by collecting the right leg into a planted base; approved specials and gated bleed grabs use that collection as their entry. There is no implied 2K-to-2S sweep gatling.",
    "whiff_vs_contact": "Whiff ends with a deliberate boot withdrawal. Contact freeze compresses the right ankle/hip relationship; block does not give an extra skid or shortcut to recovery.",
    "facing_authorship": "The right leg remains the kicking leg in both facings; maintain the left short blade above the support side.",
    "action_name": "Ankle check",
    "source_reference_id": "chipp_2k",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "6P",
        "6Hs"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [
        "236D",
        "214D"
      ],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/05.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 08. 2S — Sweep

Universal sweep input; space control and modest ordinary grounded knockdown. Wound access remains route-dependent.

**Stable slot:** 6. **Input:** 2S. **Animation clip:** `fillet_2s`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 12 / 4 / 23 |
| Absolute active frames | 12–15 |
| Recovery / next neutral | 16–38; next neutral 39 |
| Block advantage first / last active | -8 / -5 |
| Counter | Total shared freeze 21; slow 25 (13 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 9 |
| Entry inertia | 35% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 42 |
| `hitstun` | 24 |
| `blockstun` | 18 |
| `hitstop` | 9 |
| `hitLevel` | 1 |
| `pushback` | 2000 |
| `airPushback` | 2400 |
| `blockPushback` | 1400 |
| `launch` | 0 |
| `airLaunch` | 0 |
| `knockdown` | 2 |
| `knockdownFrames` | 32 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 21 |
| `counterSlowFrames` | 25 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 85 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 12 |
| `normalCancelEnd` | 21 |
| `specialCancelStart` | 12 |
| `specialCancelEnd` | 21 |
| `jumpCancelStart` | 12 |
| `jumpCancelEnd` | 19 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "low",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 35,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 336,
    "nominalDefenderOnHit": 168,
    "nominalAttackerOnBlock": 168,
    "nominalDefenderOnOrdinaryBlock": 126,
    "defenderOnFDBlock": 0,
    "FDContactCost": 350,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 85,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 12 | 1 | [[1900, 0, 11600, 2700]] |
| 4 | 15 | 1 | [[1900, 0, 10800, 2700]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |
| 10 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1200,200,7700,3100]} |
| 12 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1200,200,7700,3100]} |
| 16 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1200,200,6200,3100]} |
| 26 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      8000
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 6,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 11,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 12,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 15,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 16,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 26,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 38,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From crouch, widen the right-hand space beside the hips. From idle/run, match the crouching entry immediately and use the existing slowed root, not a new sliding approach.",
    "support_and_weight": "Left foot braces the low body while the right knee folds inward. Let the hips turn around that support without lifting the root.",
    "knife_assignment": "Long RIGHT knife describes the floor-level sweep. Short LEFT stays high beside the chest, visibly separate from the long horizontal ground shape.",
    "staging": {
      "anticipation": "Gather the long blade across the near side of the low body, making a broad lateral preparation rather than the small foot fold of 2K.",
      "contact": "Draw a low crescent with the right blade along the authored ground corridor; the hand and forearm remain much closer than the blade tip.",
      "follow_through": "Let the right arm finish extended across the front while the shoulders remain low, exposing a committed recovery silhouette.",
      "retraction": "Pull the right elbow back before unwinding the hips into crouch. Stand only through the ordinary exit once the action is free."
    },
    "geometry_and_visible_weakness": "The sweep is one low strike. A curved trail cannot create rear coverage or a circular hitbox; the exposed reaching arm stays visible.",
    "legal_cancel_bridge": "No cancel bridge is legal. Complete the low recovery, then let the next neutral input choose its action. In particular, do not draw a direct flowing Wound cancel.",
    "whiff_vs_contact": "Whiff leaves the sweeping arm extended and unsupported. On a hit, the target supplies the knockdown reaction; Fillet still finishes the authored recovery, with no automatic kneel over the target.",
    "facing_authorship": "Keep the long right knife responsible for the ground crescent in both facings; do not mirror it into the left hand.",
    "action_name": "Sweep",
    "source_reference_id": "giovanna_2d",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/06.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 09. 2Hs — Rising scissors

Predictive launcher; high vertical coverage with punishable recovery.

**Stable slot:** 7. **Input:** 2Hs. **Animation clip:** `fillet_2hs`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 14 / 5 / 24 |
| Absolute active frames | 14–18 |
| Recovery / next neutral | 19–42; next neutral 43 |
| Block advantage first / last active | -9 / -5 |
| Counter | Total shared freeze 31; slow 35 (18 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 10 |
| Entry inertia | 25% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 62 |
| `hitstun` | 29 |
| `blockstun` | 19 |
| `hitstop` | 10 |
| `hitLevel` | 0 |
| `pushback` | 2400 |
| `airPushback` | 2800 |
| `blockPushback` | 1500 |
| `launch` | 1050 |
| `airLaunch` | 1050 |
| `knockdown` | 1 |
| `knockdownFrames` | 12 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 3 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 31 |
| `counterSlowFrames` | 35 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 14 |
| `normalCancelEnd` | 24 |
| `specialCancelStart` | 14 |
| `specialCancelEnd` | 24 |
| `jumpCancelStart` | 14 |
| `jumpCancelEnd` | 22 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 1 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_only",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 25,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 496,
    "nominalDefenderOnHit": 248,
    "nominalAttackerOnBlock": 248,
    "nominalDefenderOnOrdinaryBlock": 186,
    "defenderOnFDBlock": 0,
    "FDContactCost": 400,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 14 | 1 | [[900, 4300, 6000, 15700], [3600, 10200, 8400, 19000]] |
| 5 | 18 | 1 | [[900, 4300, 5200, 15700], [3600, 10200, 7600, 19000]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |
| 12 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1100,3500,5800,12600]} |
| 14 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1100,3500,5800,12600]} |
| 19 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100],"extension":[1100,3500,4300,12600]} |
| 30 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      8000
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 7,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 13,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 14,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 18,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 19,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 30,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 42,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From crouch, open the elbows around the centerline. From a legal grounded cancel or idle/run, arrive inside the crouched entry profile first; the rise belongs to this action's upper-body movement.",
    "support_and_weight": "Both feet remain grounded. Weight begins over the right rear leg and finishes more evenly between the feet, with knees still bent under the raised torso.",
    "knife_assignment": "Long RIGHT knife supplies the tall forward diagonal; short LEFT supplies a shorter inner rising line. Together they make an open scissors silhouette, not two separate strikes.",
    "staging": {
      "anticipation": "Place the right blade low beside the body and the left blade nearer the ribs, leaving an upward lane between them.",
      "contact": "Open the blades upward, with the right weapon reaching the upper-forward corridor and the left framing the inner column.",
      "follow_through": "Hold the raised elbows and partially extended knees so the body remains committed under the high coverage.",
      "retraction": "Fold the right elbow downward, collect the short left knife above it, and sink back into the crouched exit."
    },
    "geometry_and_visible_weakness": "There is no authored vertical root track: keep the feet down. Do not turn the launcher into a jumping reversal or draw the body outside its rising crouch profile.",
    "legal_cancel_bridge": "On permitted contact, approved specials may take the raised-arm pose as entry. Otherwise complete the long lowering motion; no normal, jump, Wound or bleed-grab cancel bridge.",
    "whiff_vs_contact": "Whiff shows the blades held high with the lower body exposed. Contact freeze emphasizes the open scissors shape; the target's launch is separate from Fillet's grounded pose.",
    "facing_authorship": "Use unequal blade heights and identifiable wrists in both views so the longer right weapon never becomes an interchangeable twin.",
    "action_name": "Rising scissors",
    "source_reference_id": "chipp_2h",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_only",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/07.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 10. 6P — Shoulder guard cut

Anti-air with a precise upper-body protection window; grounded lows remain valid.

**Stable slot:** 8. **Input:** 6P. **Animation clip:** `fillet_6p`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 9 / 4 / 20 |
| Absolute active frames | 9–12 |
| Recovery / next neutral | 13–32; next neutral 33 |
| Block advantage first / last active | -8 / -5 |
| Counter | Total shared freeze 21; slow 25 (13 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 7 |
| Entry inertia | 30% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 34 |
| `hitstun` | 23 |
| `blockstun` | 15 |
| `hitstop` | 7 |
| `hitLevel` | 0 |
| `pushback` | 2200 |
| `airPushback` | 2600 |
| `blockPushback` | 1200 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 21 |
| `counterSlowFrames` | 25 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 3 |
| `hurtWindowEnd` | 12 |
| `hurtWindowMask` | 1 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 9 |
| `normalCancelEnd` | 18 |
| `specialCancelStart` | 9 |
| `specialCancelEnd` | 18 |
| `jumpCancelStart` | 9 |
| `jumpCancelEnd` | 16 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 1 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "upper anatomical regions absent on frames 3–12 only",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_only",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 30,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 272,
    "nominalDefenderOnHit": 136,
    "nominalAttackerOnBlock": 136,
    "nominalDefenderOnOrdinaryBlock": 102,
    "defenderOnFDBlock": 0,
    "FDContactCost": 300,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 9 | 1 | [[1200, 7400, 7600, 14300]] |
| 4 | 12 | 1 | [[1200, 7400, 6800, 14300]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 7 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1000,7000,5400,12800]} |
| 9 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1000,7000,5400,12800]} |
| 13 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1000,7000,3900,12800]} |
| 22 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


6P applies its legs-only mask after this body lookup on frames 3–12.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 4,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 8,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 9,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 12,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 13,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 22,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 32,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From idle/run, rotate the left shoulder toward the opponent without adding a traveling step. From a low normal, rise into a compact shoulder-led shape within this action's existing startup.",
    "support_and_weight": "Left foot supports the shoulder turn; right foot stays grounded and slightly behind. The knees and lower legs remain plainly visible below the upper-body action.",
    "knife_assignment": "Short LEFT knife travels with the leading shoulder/forearm. Long RIGHT remains tucked low behind the hip and does not form a shield across the legs.",
    "staging": {
      "anticipation": "Draw the head slightly behind the raised left shoulder while the left forearm folds inward.",
      "contact": "Present a compact upward-forward left cut, keeping the lower body exposed beneath it.",
      "follow_through": "Let the left shoulder finish forward while the right hand stays low; avoid a huge whole-body lean.",
      "retraction": "Lower the left elbow and let the head return to the open Stalker silhouette, preserving the authored end of upper-body protection."
    },
    "geometry_and_visible_weakness": "Upper-body protection is an explicit existing contract, not visible armor. Do not add a force field, full-body shimmer, airborne pose or concealed legs; lows remain visually plausible challenges.",
    "legal_cancel_bridge": "The leading shoulder can unwind into approved specials on permitted contact. No normal/jump/bleed-grab or Wound bridge is added.",
    "whiff_vs_contact": "Whiff holds the shoulder-forward shape before relaxing. Contact may make the upper cut read as a crisp interruption, but neither hit nor block adds a shield reaction or extra protective time.",
    "facing_authorship": "The red left shoulder armor and short left knife must stay on the same anatomical side after the view reverses.",
    "action_name": "Shoulder guard cut",
    "source_reference_id": "chipp_6p",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_only",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/08.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 11. 6Hs — Chasing cleave

Slow advancing commitment and counter-hit conversion tool.

**Stable slot:** 11. **Input:** 6Hs. **Animation clip:** `fillet_6hs`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 18 / 4 / 25 |
| Absolute active frames | 18–21 |
| Recovery / next neutral | 22–46; next neutral 47 |
| Block advantage first / last active | -8 / -5 |
| Counter | Total shared freeze 31; slow 35 (18 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 11 |
| Entry inertia | 35% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 72 |
| `hitstun` | 31 |
| `blockstun` | 20 |
| `hitstop` | 11 |
| `hitLevel` | 0 |
| `pushback` | 3200 |
| `airPushback` | 3600 |
| `blockPushback` | 1600 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 3 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 31 |
| `counterSlowFrames` | 35 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 18 |
| `normalCancelEnd` | 27 |
| `specialCancelStart` | 18 |
| `specialCancelEnd` | 27 |
| `jumpCancelStart` | 18 |
| `jumpCancelEnd` | 25 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [
      "236P",
      "236S",
      "236K",
      "623Hs"
    ],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [
      "236D",
      "214D"
    ],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded",
    "bleedGrabWindow": [
      18,
      27
    ],
    "bleedGrabPriority": "dedicated authoritative route overrides legacy Throw-destination rejection and source specialCancel only for these listed command targets; requires actual hit/block, five elapsed attacker ticks, owned bleed and the listed window. Ordinary normal-throw cancels remain forbidden."
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 35,
    "instantAdvance": 0,
    "startupTravelPerTick": 100,
    "activeTravelPerTick": 150,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 576,
    "nominalDefenderOnHit": 288,
    "nominalAttackerOnBlock": 288,
    "nominalDefenderOnOrdinaryBlock": 216,
    "defenderOnFDBlock": 0,
    "FDContactCost": 400,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 18 | 1 | [[2600, 3500, 13300, 10800], [2100, 10200, 9400, 14200]] |
| 4 | 21 | 1 | [[2600, 3500, 12500, 10800], [2100, 10200, 8600, 14200]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 16 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1600,4200,8700,13200]} |
| 18 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1600,4200,8700,13200]} |
| 22 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1600,4200,7200,13200]} |
| 33 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 9,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 17,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 18,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 21,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 22,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 33,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 46,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From idle/run, begin a measured chasing step using the action's authored travel. From another heavy, gather the existing upper-body finish into a low right-hand coil instead of resetting to idle.",
    "support_and_weight": "Drive visual weight from the rear right leg toward a planting left foot. Let the rear foot follow the actual moving root; do not show a planted boot sliding.",
    "knife_assignment": "Long RIGHT knife leads the larger advancing cleave. Short LEFT stays high and nearer the body, adding a smaller upper accent within the same contact.",
    "staging": {
      "anticipation": "Turn the right shoulder back and open the chest enough to show a slower commitment; keep the head looking toward the opponent.",
      "contact": "Bring the right blade forward in a broad diagonal as the lead foot accepts the chase step.",
      "follow_through": "Leave the right shoulder and forearm stretched forward after the cut, with the rear heel still following the step.",
      "retraction": "Gather the right elbow, recover the rear foot under the body, then reopen the left-hand high guard."
    },
    "geometry_and_visible_weakness": "Use only the stated root travel. Do not add a leap, overshoot, second stride, extended knife length or invulnerable shoulder charge.",
    "legal_cancel_bridge": "Approved specials take the extended heavy finish as entry; gated bleed grabs first collect the traveling base into their distinct hop/skim preparations. No free dash, jump or Wound exit.",
    "whiff_vs_contact": "Whiff looks committed because the body has advanced and the long arm must return. Hit/block freeze the same chase silhouette; neither result adds an automatic follow-up.",
    "facing_authorship": "The rear long right blade must remain identifiable during the broad preparation in both facings; redraw the shoulder overlap rather than copying a mirrored arm swap.",
    "action_name": "Chasing cleave",
    "source_reference_id": "chipp_6h",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [
        "236P",
        "236S",
        "236K",
        "623Hs"
      ],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [
        "236D",
        "214D"
      ],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/11.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 12. j.P — Air check

Quick air-to-air; modest reward and narrow forward volume.

**Stable slot:** 17. **Input:** j.P. **Animation clip:** `fillet_j_p`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 5 / 3 / 10 |
| Absolute active frames | 5–7 |
| Recovery / next neutral | 8–17; next neutral 18 |
| Block advantage first / last active | -2 / +0 |
| Counter | Total shared freeze 9; slow 0 (0 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 6 |
| Entry inertia | 70% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 22 |
| `hitstun` | 15 |
| `blockstun` | 10 |
| `hitstop` | 6 |
| `hitLevel` | 2 |
| `pushback` | 1200 |
| `airPushback` | 1600 |
| `blockPushback` | 600 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 1 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 9 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 3 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 80 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 5 |
| `normalCancelEnd` | 13 |
| `specialCancelStart` | 5 |
| `specialCancelEnd` | 13 |
| `jumpCancelStart` | 5 |
| `jumpCancelEnd` | 11 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "overhead",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "j.P",
      "j.K"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "hit_or_block",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 70,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 176,
    "nominalDefenderOnHit": 88,
    "nominalAttackerOnBlock": 88,
    "nominalDefenderOnOrdinaryBlock": 66,
    "defenderOnFDBlock": 0,
    "FDContactCost": 250,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 80,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 5 | 1 | [[2100, 6900, 6900, 10200]] |
| 3 | 7 | 1 | [[2100, 6900, 6100, 10200]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000]} |
| 3 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,6300,5800,10800]} |
| 5 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,6300,5800,10800]} |
| 8 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,6300,4300,10800]} |
| 12 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 2,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 4,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 5,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 7,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 8,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 12,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 17,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "jump ascent",
    "apex",
    "descent",
    "forward air dash after its lockout",
    "air-normal cancel"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "air/landing controller",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "Enter from ascent, apex, descent, an unlocked forward airdash or an allowed air-normal cancel. Preserve the current airborne root trajectory; there is no ground-stance entry or suspended preparation.",
    "support_and_weight": "There is no support foot. Keep the pelvis as the visual center with both knees lightly gathered; the right leg hangs slightly farther back as counterweight.",
    "knife_assignment": "Short LEFT knife checks the narrow forward volume. Long RIGHT stays near the right thigh, separated from the left arm.",
    "staging": {
      "anticipation": "Fold the left elbow close to the upper torso without pulling the whole body backward.",
      "contact": "Extend the short blade horizontally at the airborne chest line, with a compact shoulder reach.",
      "follow_through": "Keep the hips on their incoming path while only the left forearm finishes forward.",
      "retraction": "Collect the left elbow and restore the ordinary air tuck; prepare the feet for landing only when the real trajectory calls for it."
    },
    "geometry_and_visible_weakness": "Do not create a full aerial spin, long tip reach or a momentary hover. The reaching forearm remains exposed.",
    "legal_cancel_bridge": "On legal contact, fold into j.P/j.K or the allowed jump/airdash exit; the same pelvis center carries the bridge. Landing takes priority under the main contract and removes the air attack rather than drawing a grounded final slash.",
    "whiff_vs_contact": "Whiff is a small arm-only check. Contact freezes the airborne body for the declared hitstop, then resumes the same trajectory; no recoil propulsion is introduced.",
    "facing_authorship": "The left blade remains short even when the arm is nearer camera; keep the right knife visible below rather than hiding a hand swap in the air tuck.",
    "action_name": "Air check",
    "source_reference_id": "chipp_jp",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "j.P",
        "j.K"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "hit_or_block",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/17.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 13. j.K — Descending kick

Downward air check; knee and foot remain vulnerable.

**Stable slot:** 18. **Input:** j.K. **Animation clip:** `fillet_j_k`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 7 / 4 / 13 |
| Absolute active frames | 7–10 |
| Recovery / next neutral | 11–23; next neutral 24 |
| Block advantage first / last active | -3 / +0 |
| Counter | Total shared freeze 9; slow 0 (0 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 6 |
| Entry inertia | 70% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 30 |
| `hitstun` | 19 |
| `blockstun` | 13 |
| `hitstop` | 6 |
| `hitLevel` | 2 |
| `pushback` | 1700 |
| `airPushback` | 2100 |
| `blockPushback` | 800 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 1 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 9 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 4 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 7 |
| `normalCancelEnd` | 16 |
| `specialCancelStart` | 7 |
| `specialCancelEnd` | 16 |
| `jumpCancelStart` | 7 |
| `jumpCancelEnd` | 14 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "overhead",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "j.S"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "hit_or_block",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 70,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 240,
    "nominalDefenderOnHit": 120,
    "nominalAttackerOnBlock": 120,
    "nominalDefenderOnOrdinaryBlock": 90,
    "defenderOnFDBlock": 0,
    "FDContactCost": 300,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 7 | 1 | [[2000, -1500, 8900, 3800]] |
| 4 | 10 | 1 | [[2000, -1500, 8100, 3800]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000]} |
| 5 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,-1400,8300,4400]} |
| 7 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,-1400,8300,4400]} |
| 11 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,-1400,6800,4400]} |
| 16 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 3,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 6,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 7,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 10,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 11,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 16,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 23,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "jump ascent",
    "apex",
    "descent",
    "forward air dash after its lockout",
    "air-normal cancel"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "air/landing controller",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "Enter from the actual airborne pose, retaining ascent/descent or dash momentum. Bring the right knee forward from that pose rather than resetting to a generic jumping silhouette.",
    "support_and_weight": "No foot supports weight. Counter-rotate the upper body slightly while the right leg extends down-forward and the left knee remains collected.",
    "knife_assignment": "Long RIGHT knife stays outside the right hip above the kicking thigh; short LEFT guards near the chest. Neither follows the foot as a damaging trail.",
    "staging": {
      "anticipation": "Lift the right knee toward the torso, leaving clear negative space between the knee and the knives.",
      "contact": "Extend the right boot into the lower-forward corridor, visibly below the torso rather than level with j.P.",
      "follow_through": "Keep the right shin extended while the left knee balances the silhouette; the pelvis continues its authored flight.",
      "retraction": "Fold the right knee back into the air pose. If actual landing arrives first, use the specified landing state instead of finishing the aerial fold."
    },
    "geometry_and_visible_weakness": "The boot and lower leg remain visibly vulnerable. Do not add a dive acceleration, bounce, ground skip or extra low-classified strike.",
    "legal_cancel_bridge": "Collect the right knee into j.S's downward blade preparation on legal contact. Approved jump/airdash exits reuse the same gathered-leg silhouette; no grounded bridge appears before landing recovery allows one.",
    "whiff_vs_contact": "On whiff, the extended leg must visibly recover. Contact compresses the ankle/hip shape during the declared freeze, without rebounding Fillet upward.",
    "facing_authorship": "Keep the kicking leg anatomical right in both views and redraw the knife/leg overlap so the long right blade is not mistaken for the boot's hit area.",
    "action_name": "Descending kick",
    "source_reference_id": "chipp_jk",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "j.S"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "hit_or_block",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/18.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 14. j.S — Falling knife

Main jump-in with forward and lower coverage; exposed landing.

**Stable slot:** 19. **Input:** j.S. **Animation clip:** `fillet_j_s`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 10 / 4 / 17 |
| Absolute active frames | 10–13 |
| Recovery / next neutral | 14–30; next neutral 31 |
| Block advantage first / last active | -4 / -1 |
| Counter | Total shared freeze 21; slow 25 (13 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 8 |
| Entry inertia | 65% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 42 |
| `hitstun` | 23 |
| `blockstun` | 16 |
| `hitstop` | 8 |
| `hitLevel` | 2 |
| `pushback` | 2200 |
| `airPushback` | 2600 |
| `blockPushback` | 1100 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 21 |
| `counterSlowFrames` | 25 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 4 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 10 |
| `normalCancelEnd` | 19 |
| `specialCancelStart` | 10 |
| `specialCancelEnd` | 19 |
| `jumpCancelStart` | 10 |
| `jumpCancelEnd` | 17 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "overhead",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [
      "j.Hs"
    ],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "hit_or_block",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 65,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 336,
    "nominalDefenderOnHit": 168,
    "nominalAttackerOnBlock": 168,
    "nominalDefenderOnOrdinaryBlock": 126,
    "defenderOnFDBlock": 0,
    "FDContactCost": 350,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 10 | 1 | [[1800, 1000, 10800, 8200], [2400, -2000, 7600, 3000]] |
| 4 | 13 | 1 | [[1800, 1000, 10000, 8200], [2400, -2000, 6800, 3000]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000]} |
| 8 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,900,6900,9000]} |
| 10 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,900,6900,9000]} |
| 14 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1500,900,5400,9000]} |
| 21 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 5,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 9,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 10,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 13,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 14,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 21,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 30,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "jump ascent",
    "apex",
    "descent",
    "forward air dash after its lockout",
    "air-normal cancel"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "air/landing controller",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "Enter from the current air path or a legal j.K cancel. Inherit the existing torso angle and draw the right elbow into the falling-cut preparation without pausing descent.",
    "support_and_weight": "No support foot: the pelvis remains the pivot, left knee gathered and right leg slightly lower to counter the forward blade reach.",
    "knife_assignment": "Long RIGHT knife makes the descending forward cut. Short LEFT stays above and closer to the shoulder, clearing the long blade's lower path.",
    "staging": {
      "anticipation": "Raise the right hand beside the upper torso while the left elbow frames a compact opening over it.",
      "contact": "Draw the long right blade diagonally down-forward, matching the connected forward and below-root attack volumes.",
      "follow_through": "Let the right forearm finish down in front of the hips while the torso tilts only within its authored hurt shape.",
      "retraction": "Recover the right elbow upward toward the torso; collect the legs for the real landing rather than inventing an extra aerial flourish."
    },
    "geometry_and_visible_weakness": "The exposed forearm and eventual landing must remain readable. No root dive, float, ground scrape or extra trail reach is added.",
    "legal_cancel_bridge": "Use the down-forward finish as the start of j.Hs's torso turn, or gather into a permitted jump/airdash exit. If landing occurs, obey the central landing cutoff before any supposed last airborne contact.",
    "whiff_vs_contact": "Whiff completes the downward arc into empty space. Hit/block freezes the same descending silhouette; the blade does not stick to the victim or pull Fillet along.",
    "facing_authorship": "The long right blade stays the lower forward weapon in both facings; keep a separate short-left silhouette above so the two hands never merge.",
    "action_name": "Falling knife",
    "source_reference_id": "chipp_js",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [
        "j.Hs"
      ],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "hit_or_block",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/19.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 15. j.Hs — Turning scissors

Broad air commitment; late rear coverage supplies occasional cross-up.

**Stable slot:** 20. **Input:** j.Hs. **Animation clip:** `fillet_j_hs`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 13 / 5 / 22 |
| Absolute active frames | 13–17 |
| Recovery / next neutral | 18–39; next neutral 40 |
| Block advantage first / last active | -8 / -4 |
| Counter | Total shared freeze 31; slow 35 (18 extra held ticks); +0 hitstun; applies=True |
| Ordinary freeze | 10 |
| Entry inertia | 60% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 55 |
| `hitstun` | 27 |
| `blockstun` | 18 |
| `hitstop` | 10 |
| `hitLevel` | 2 |
| `pushback` | 2700 |
| `airPushback` | 3100 |
| `blockPushback` | 1400 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 3 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 31 |
| `counterSlowFrames` | 35 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 6 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 13 |
| `normalCancelEnd` | 23 |
| `specialCancelStart` | 13 |
| `specialCancelEnd` | 23 |
| `jumpCancelStart` | 13 |
| `jumpCancelEnd` | 21 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "overhead",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 60,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 440,
    "nominalDefenderOnHit": 220,
    "nominalAttackerOnBlock": 220,
    "nominalDefenderOnOrdinaryBlock": 165,
    "defenderOnFDBlock": 0,
    "FDContactCost": 350,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 13 | 1 | [[1200, 1400, 10400, 9500], [-3000, 3900, 2400, 10700]] |
| 5 | 17 | 1 | [[-5700, 2900, 3400, 10100], [1400, 1800, 8700, 8700]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000]} |
| 11 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[100,2300,6500,10900]} |
| 13 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[100,2300,6500,10900]} |
| 18 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[100,2300,5000,10900]} |
| 28 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 6,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 12,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 13,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 17,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 18,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 28,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 39,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "jump ascent",
    "apex",
    "descent",
    "forward air dash after its lockout",
    "air-normal cancel"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "air/landing controller",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "Enter from the actual air pose, especially j.S's lowered right-hand finish. Begin a compact torso turn around the current airborne root rather than starting a new jump or somersault.",
    "support_and_weight": "No ground support. The knees gather on different sides of the pelvis to make the turn legible; the hips do not change the gameplay flight direction.",
    "knife_assignment": "Long RIGHT knife supplies the larger rotating arc and the pronounced late rear silhouette. Short LEFT remains the smaller forward/inner accent.",
    "staging": {
      "anticipation": "Separate the elbows around the torso, with the long blade recognizable across the near side before the turn.",
      "contact": "Show the first broad front shape and the smaller rear blade presence as one turning attack.",
      "follow_through": "As the turn progresses, let the long right blade become clearly visible behind Fillet for the authored late rear coverage; the left blade remains the shorter forward shape.",
      "retraction": "Collect both elbows toward the body and return the legs to a landing-ready air pose, leaving the heavy recovery visibly unfinished until legal release."
    },
    "geometry_and_visible_weakness": "Rear coverage is phase-specific, not a full circular aura. Keep the root path unchanged and do not turn the visual spin into a second hit group or automatic facing update.",
    "legal_cancel_bridge": "No outgoing cancel bridge is legal. Complete the heavy air recovery or transition into the specified landing recovery if the floor arrives first.",
    "whiff_vs_contact": "Whiff visibly carries the committed turn through. Contact uses only the listed hit group and freeze; no extra backslash, spin continuation or landing hit is implied.",
    "facing_authorship": "Author front and rear torso views so the anatomical right hand still carries the long knife when it appears behind the body; a horizontal sprite mirror is insufficient.",
    "action_name": "Turning scissors",
    "source_reference_id": "chipp_jh",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/20.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 16. 236P — Needle check

Straight mid special: interrupt predictable challenges and finish pressure safely at space.

**Stable slot:** 14. **Input:** 236P. **Animation clip:** `fillet_236p`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 12 / 3 / 16 |
| Absolute active frames | 12–14 |
| Recovery / next neutral | 15–30; next neutral 31 |
| Block advantage first / last active | -4 / -2 |
| Counter | Total shared freeze 10; slow 0 (0 extra held ticks); +3 hitstun; applies=True |
| Ordinary freeze | 7 |
| Entry inertia | 45% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 34 |
| `hitstun` | 22 |
| `blockstun` | 14 |
| `hitstop` | 7 |
| `hitLevel` | 0 |
| `pushback` | 2500 |
| `airPushback` | 2900 |
| `blockPushback` | 1200 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 2 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 1 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 10 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 3 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 12 |
| `normalCancelEnd` | 20 |
| `specialCancelStart` | 12 |
| `specialCancelEnd` | 20 |
| `jumpCancelStart` | 12 |
| `jumpCancelEnd` | 18 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 45,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 100,
    "startCost": 0,
    "nominalAttackerOnHit": 272,
    "nominalDefenderOnHit": 136,
    "nominalAttackerOnBlock": 136,
    "nominalDefenderOnOrdinaryBlock": 102,
    "defenderOnFDBlock": 0,
    "FDContactCost": 300,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 2,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 12 | 1 | [[3200, 6600, 12700, 9300]] |
| 3 | 14 | 1 | [[3200, 6600, 11900, 9300]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 10 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,6100,8000,10500]} |
| 12 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,6100,8000,10500]} |
| 15 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,6100,6500,10500]} |
| 22 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 6,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 11,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 12,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 14,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 15,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 22,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 30,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From idle/run or an approved normal cancel, gather into a narrow two-hand bracket in front of the chest. Preserve the current support foot and the specified retained inertia; do not add a special dash.",
    "support_and_weight": "Both feet stay grounded, with the left foot normally accepting the small forward shoulder shift and the right heel providing the visual brace.",
    "knife_assignment": "Long RIGHT knife creates the straight mid line. Short LEFT stays close to the chest and slightly above it, clearly framing rather than extending that line.",
    "staging": {
      "anticipation": "Draw the right elbow back inside the silhouette while the left elbow closes above it; this is more compressed and squared than f.S's reaching preparation.",
      "contact": "Project a narrow right-blade line through the authored horizontal corridor, with the torso staying relatively centered behind the arm.",
      "follow_through": "Keep the right arm extended briefly and the left blade near the body, making the special read as a single deliberate check.",
      "retraction": "Return the right elbow to the bracket, then reopen the asymmetrical Stalker hands."
    },
    "geometry_and_visible_weakness": "The reaching right arm remains vulnerable. Do not add a projectile, beam, knife extension or automatic body lunge to sell the 'needle' name.",
    "legal_cancel_bridge": "No outgoing cancel is legal. The bracket opens back into neutral only after the authored recovery; do not imply a rekka or a second input branch.",
    "whiff_vs_contact": "Whiff is a clean straight extension and withdrawal. Contact creates a compact line/spark during declared freeze; block may check the shoulder without making the move recoil across the floor.",
    "facing_authorship": "Maintain the long right blade as the projected line in both views; the short left blade remains a visibly shorter close frame.",
    "action_name": "Needle check",
    "source_reference_id": "lancelot_dual_blade",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/14.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 17. 236S — Opening cut

Pressure entry with delayable high/low branches; never an automatic mix victory.

**Stable slot:** 15. **Input:** 236S. **Animation clip:** `fillet_236s`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 9 / 3 / 18 |
| Absolute active frames | 9–11 |
| Recovery / next neutral | 12–29; next neutral 30 |
| Block advantage first / last active | -3 / -1 |
| Counter | Total shared freeze 10; slow 0 (0 extra held ticks); +3 hitstun; applies=True |
| Ordinary freeze | 7 |
| Entry inertia | 65% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 28 |
| `hitstun` | 26 |
| `blockstun` | 17 |
| `hitstop` | 7 |
| `hitLevel` | 0 |
| `pushback` | 1000 |
| `airPushback` | 1400 |
| `blockPushback` | 700 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 1 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 10 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 3 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 9 |
| `normalCancelEnd` | 17 |
| `specialCancelStart` | 9 |
| `specialCancelEnd` | 17 |
| `jumpCancelStart` | 9 |
| `jumpCancelEnd` | 15 |
| `followCancelStart` | 9 |
| `followCancelEnd` | 17 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [
      "236S>6S",
      "236S>2S"
    ],
    "followWindow": [
      9,
      17
    ],
    "followCondition": "contact on hit or block; no whiff branch",
    "bleedGrabTargets": [
      "236D",
      "214D"
    ],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded",
    "bleedGrabWindow": [
      9,
      17
    ],
    "bleedGrabPriority": "dedicated authoritative route overrides legacy Throw-destination rejection and source specialCancel only for these listed command targets; requires actual hit/block, five elapsed attacker ticks, owned bleed and the listed window. Ordinary normal-throw cancels remain forbidden."
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 65,
    "instantAdvance": 0,
    "startupTravelPerTick": 200,
    "activeTravelPerTick": 100,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 100,
    "startCost": 0,
    "nominalAttackerOnHit": 224,
    "nominalDefenderOnHit": 112,
    "nominalAttackerOnBlock": 112,
    "nominalDefenderOnOrdinaryBlock": 84,
    "defenderOnFDBlock": 0,
    "FDContactCost": 300,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 9 | 1 | [[2000, 4200, 10500, 11200]] |
| 3 | 11 | 1 | [[2000, 4200, 9700, 11200]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 7 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1400,4400,6800,12000]} |
| 9 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1400,4400,6800,12000]} |
| 12 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1400,4400,5300,12000]} |
| 20 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 4,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 8,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 9,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 11,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 12,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 20,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 29,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From idle/run, let the authored forward movement carry a small closing step. From an approved normal cancel, gather the prior blade position into a mid-height opening cut without a neutral reset.",
    "support_and_weight": "Weight travels from the rear right leg into the left lead foot as the gameplay root advances. Keep the hips centered enough that either branch remains visually possible.",
    "knife_assignment": "Long RIGHT knife leads the broad opening cut. Short LEFT stays high near the chest, framing the action and reserving its forearm for a later legal grab entry.",
    "staging": {
      "anticipation": "Coil the right hand low beside the hip while the left elbow opens a narrow upper gap.",
      "contact": "Unfold the right blade diagonally through the middle corridor while the lead foot accepts the closing step.",
      "follow_through": "Finish with the right elbow in front of the waist and the blade neither fully high nor fully low. This shared loaded finish supports the authored branch window.",
      "retraction": "If no follow-up is chosen, gather the right elbow slowly back to the low Stalker position while the rear foot catches the actual root."
    },
    "geometry_and_visible_weakness": "A branch-ready pose must not become an indefinite hold, a fake second active swing, or a pause in recovery. Keep the exposed right forearm visible through the timeline.",
    "legal_cancel_bridge": "Only confirmed hit/block enters the named 236S>6S or 236S>2S branch. Raise the right hand for Crown cut or collapse the hips/right hand for Heel cut; a delayed branch leaves from the currently advancing pose. Gated bleed grabs lead with the left forearm. No whiff branch or Wound bridge.",
    "whiff_vs_contact": "Whiff completes the closing cut and runs out its recovery. Hit/block adds the declared freeze and permits the actual branch input; no automatic flourish should make a nonexistent branch appear.",
    "facing_authorship": "In both facings, preserve the right-blade lead and high short-left frame, including any near/far-arm overlap at the shared branch pose.",
    "action_name": "Opening cut",
    "source_reference_id": "lancelot_dual_blade",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [
        "236S>6S",
        "236S>2S"
      ],
      "followWindow": [
        9,
        17
      ],
      "followCondition": "contact on hit or block; no whiff branch",
      "jumpCondition": "none",
      "bleedGrabTargets": [
        "236D",
        "214D"
      ],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/15.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 18. 236S > 6S — Crown cut

Overhead branch. Rewards a successful high mix with enough knockdown time for Wound.

**Stable slot:** 26. **Input:** 236S > 6S. **Animation clip:** `fillet_236s_6s`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 21 / 3 / 22 |
| Absolute active frames | 21–23 |
| Recovery / next neutral | 24–45; next neutral 46 |
| Block advantage first / last active | -6 / -4 |
| Counter | Total shared freeze 18; slow 0 (0 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 9 |
| Entry inertia | 20% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 48 |
| `hitstun` | 26 |
| `blockstun` | 18 |
| `hitstop` | 9 |
| `hitLevel` | 2 |
| `pushback` | 1200 |
| `airPushback` | 1600 |
| `blockPushback` | 1400 |
| `launch` | 0 |
| `airLaunch` | 0 |
| `knockdown` | 2 |
| `knockdownFrames` | 56 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 2 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 18 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 85 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 21 |
| `normalCancelEnd` | 29 |
| `specialCancelStart` | 21 |
| `specialCancelEnd` | 29 |
| `jumpCancelStart` | 21 |
| `jumpCancelEnd` | 27 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | 15 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "overhead",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 20,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 100,
    "startCost": 0,
    "nominalAttackerOnHit": 384,
    "nominalDefenderOnHit": 192,
    "nominalAttackerOnBlock": 192,
    "nominalDefenderOnOrdinaryBlock": 144,
    "defenderOnFDBlock": 0,
    "FDContactCost": 350,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 85,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 2,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 21 | 1 | [[2700, 5100, 10400, 13700], [5500, 2300, 10800, 7000]] |
| 3 | 23 | 1 | [[2700, 5100, 9600, 13700], [5500, 2300, 10000, 7000]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 19 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,5600,7000,13400]} |
| 21 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,5600,7000,13400]} |
| 24 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1700,5600,5500,13400]} |
| 34 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 6,
      "label": "branch_divergence",
      "guide": "First visually distinct high/low pose; exact body profile from this frame."
    },
    {
      "frame": 10,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 20,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 21,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 23,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 24,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 34,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 45,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "236S contact follow-up at a permitted completed frame"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "Enter only from a legal 236S contact follow-up. Carry the opening cut's right-hand position into the higher preparation; there is no independent idle, run, crouch or airborne entry.",
    "support_and_weight": "The left foot remains planted from the opening step, and the right heel supports a tall grounded coil. Do not introduce a hop.",
    "knife_assignment": "Long RIGHT knife rises to define the overhead silhouette. Short LEFT remains nearer the chest, slightly lower, and clears the descending right-blade path.",
    "staging": {
      "anticipation": "Lift the right elbow and blade above the front shoulder within the existing anticipation, making a distinct tall shape as soon as this branch has begun.",
      "contact": "Bring the long blade down through the authored upper-to-lower forward corridor, with the body staying grounded.",
      "follow_through": "Let the right shoulder and elbow finish low-forward while the torso settles over the planted lead foot.",
      "retraction": "Collect the right blade inward before returning to Stalker; keep the exposed upper body readable during the recovery."
    },
    "geometry_and_visible_weakness": "Overhead guard classification does not require airborne art. Do not add root height, a jumping knee, rear coverage or a second lower strike.",
    "legal_cancel_bridge": "No outgoing cancel is legal. Complete the grounded recovery before any later neutral Wound attempt; do not animate a direct cut-to-Wound continuation.",
    "whiff_vs_contact": "Whiff carries the downward arc into empty space. On hit, the opponent takes the specified knockdown while Fillet completes the same recovery; on block, a local checked elbow replaces any dramatic follow-through shove.",
    "facing_authorship": "Draw the right wrist and long blade clearly above the short left blade in both facings; preserve the left shoulder armor during the raised silhouette.",
    "action_name": "Crown cut",
    "source_reference_id": "lancelot_dual_blade",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/26.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 19. 236S > 2S — Heel cut

Low branch. May be delayed to share the overhead impact timing.

**Stable slot:** 27. **Input:** 236S > 2S. **Animation clip:** `fillet_236s_2s`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 16 / 3 / 24 |
| Absolute active frames | 16–18 |
| Recovery / next neutral | 19–42; next neutral 43 |
| Block advantage first / last active | -9 / -7 |
| Counter | Total shared freeze 16; slow 0 (0 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 8 |
| Entry inertia | 20% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 40 |
| `hitstun` | 26 |
| `blockstun` | 17 |
| `hitstop` | 8 |
| `hitLevel` | 1 |
| `pushback` | 1200 |
| `airPushback` | 1600 |
| `blockPushback` | 1400 |
| `launch` | 0 |
| `airLaunch` | 0 |
| `knockdown` | 2 |
| `knockdownFrames` | 56 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 2 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 16 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 85 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 16 |
| `normalCancelEnd` | 24 |
| `specialCancelStart` | 16 |
| `specialCancelEnd` | 24 |
| `jumpCancelStart` | 16 |
| `jumpCancelEnd` | 22 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | 15 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "low",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 20,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 100,
    "startCost": 0,
    "nominalAttackerOnHit": 320,
    "nominalDefenderOnHit": 160,
    "nominalAttackerOnBlock": 160,
    "nominalDefenderOnOrdinaryBlock": 120,
    "defenderOnFDBlock": 0,
    "FDContactCost": 350,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 85,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 2,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 16 | 1 | [[2500, 0, 11200, 2900]] |
| 3 | 18 | 1 | [[2500, 0, 10400, 2900]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 6 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |
| 14 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1600,200,7800,3300]} |
| 16 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1600,200,7800,3300]} |
| 19 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1600,200,6300,3300]} |
| 30 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      8000
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": {
    "basis": "absolute action frames; hold until next key",
    "keys": [
      {
        "frame": 1,
        "box": [
          -2800,
          0,
          2800,
          13800
        ]
      },
      {
        "frame": 6,
        "box": [
          -2800,
          0,
          2800,
          8000
        ]
      }
    ]
  },
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 6,
      "label": "branch_divergence",
      "guide": "First visually distinct high/low pose; exact body profile from this frame."
    },
    {
      "frame": 8,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 15,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 16,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 18,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 19,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 30,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 42,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "236S contact follow-up at a permitted completed frame"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "Enter only from a legal 236S contact follow-up. The first branch pose must already fit the crouching entry profile, taking the opening cut's right hand downward without adding a standing dip before the branch.",
    "support_and_weight": "Left foot braces the compressed body; right knee folds inward so the hips can make a small low lateral turn without a new sliding root.",
    "knife_assignment": "Long RIGHT knife makes the low draw across the floor corridor. Short LEFT stays gathered beside the chest, higher than the ground cut.",
    "staging": {
      "anticipation": "Set the right elbow low behind the front knee, with the torso compressed enough to distinguish the chosen low branch from Crown cut.",
      "contact": "Send the long blade along a low horizontal crescent, tighter through the torso than the standalone 2S sweep.",
      "follow_through": "Finish with the right hand extended low-forward and the left hand still collected, keeping the low recovery visibly committed.",
      "retraction": "Recover the right elbow beside the bent knee, then reopen the crouched hands; stand only through the ordinary legal exit."
    },
    "geometry_and_visible_weakness": "Do not turn the low branch into a foot sweep, long slide, or under-everything profile. The authored body/forearm volumes determine vulnerability.",
    "legal_cancel_bridge": "No outgoing cancel is legal. The delayed choice is made from 236S's real follow window; once this branch starts, its recovery cannot be skipped into Wound or another rekka.",
    "whiff_vs_contact": "Whiff leaves the low arm extended and then retracting. Contact uses the same floor-level shape with one hit event; the target reaction distinguishes hit from block without a second cutting motion.",
    "facing_authorship": "The long right blade owns the low path on both sides of the screen; keep the left short blade high enough to avoid an ambiguous crossed ground trail.",
    "action_name": "Heel cut",
    "source_reference_id": "giovanna_2d",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/27.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 20. 236K — Passing cut

Committed side-pass special with a visible cross-through, finite travel and punishable block.

**Stable slot:** 25. **Input:** 236K. **Animation clip:** `fillet_236k`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 27 / 3 / 24 |
| Absolute active frames | 27–29 |
| Recovery / next neutral | 30–53; next neutral 54 |
| Block advantage first / last active | -10 / -8 |
| Counter | Total shared freeze 18; slow 16 (8 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 8 |
| Entry inertia | 0% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 36 |
| `hitstun` | 23 |
| `blockstun` | 16 |
| `hitstop` | 8 |
| `hitLevel` | 0 |
| `pushback` | 2400 |
| `airPushback` | 2800 |
| `blockPushback` | 1400 |
| `launch` | 0 |
| `airLaunch` | 650 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 18 |
| `counterSlowFrames` | 16 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 27 |
| `normalCancelEnd` | 35 |
| `specialCancelStart` | 27 |
| `specialCancelEnd` | 35 |
| `jumpCancelStart` | 27 |
| `jumpCancelEnd` | 33 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 0,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [
      {
        "first": 9,
        "last": 20,
        "dx": 1250,
        "dy": 0,
        "collision": "pass_through_opponent_pushbox_only; stage walls still clamp"
      }
    ],
    "facing": "lock at entry; single target-relative facing update after frame20; lock again through recovery",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 100,
    "startCost": 0,
    "nominalAttackerOnHit": 288,
    "nominalDefenderOnHit": 144,
    "nominalAttackerOnBlock": 144,
    "nominalDefenderOnOrdinaryBlock": 108,
    "defenderOnFDBlock": 0,
    "FDContactCost": 300,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 27 | 1 | [[2000, 4200, 10800, 10500]] |
| 3 | 29 | 1 | [[2000, 4200, 10000, 10500]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 25 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1100,4200,7000,11300]} |
| 27 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1100,4200,7000,11300]} |
| 30 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1100,4200,5500,11300]} |
| 41 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 13,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 26,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 27,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 29,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 30,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 41,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 53,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From idle/run or an approved normal cancel, compact both arms close to the torso before the finite pass. Retained run motion is not an extra approach: use the central action root track.",
    "support_and_weight": "Use short traveling foot poses during the pass, then a visible plant at its end. Pivot through the real support foot only at the declared late facing update, conditional on the opponent's actual side.",
    "knife_assignment": "Long RIGHT knife folds low along the right side during travel, then opens for the post-pass cut. Short LEFT stays near the chest and remains the shorter counter-shape during the turn.",
    "staging": {
      "anticipation": "Turn the torso slightly side-on and gather both elbows; the silhouette announces movement before a strike.",
      "contact": "After travel and the authorized facing update, extend the right blade through the forward middle corridor relative to that final facing.",
      "follow_through": "Let the cutting shoulder finish toward the opponent while both feet remain at the completed pass location.",
      "retraction": "Bring the right blade back low and square the hips into Stalker, leaving the committed post-pass recovery visible."
    },
    "geometry_and_visible_weakness": "Travel is not an attack or invulnerable vanish. Do not draw damaging slash trails during the pass, extra displacement, a second facing correction or a teleport flash. If the pass does not cross, the art must still face the actual opponent.",
    "legal_cancel_bridge": "No outgoing cancel is legal. The turn and post-pass cut run to their recovery or real interruption; do not blend directly into a fresh run or grab before release.",
    "whiff_vs_contact": "Whiff shows the post-pass cut missing and Fillet collecting the feet in place. Contact freezes only the cut; crossing the body alone produces no impact cue.",
    "facing_authorship": "Create separate turning views that keep the long knife on the right hand and the red shoulder on the left. A mirrored sprite pop at the facing change is not an acceptable turn.",
    "action_name": "Passing cut",
    "source_reference_id": "lancelot_dual_blade",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/25.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 21. 623Hs — Rising carve

Non-invulnerable rising ender/anti-air; high reward only after a correct read or confirm.

**Stable slot:** 16. **Input:** 623Hs. **Animation clip:** `fillet_623hs`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 11 / 5 / 29 |
| Absolute active frames | 11–15 |
| Recovery / next neutral | 16–44; next neutral 45 |
| Block advantage first / last active | -16 / -12 |
| Counter | Total shared freeze 20; slow 16 (8 extra held ticks); +4 hitstun; applies=True |
| Ordinary freeze | 10 |
| Entry inertia | 20% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 64 |
| `hitstun` | 29 |
| `blockstun` | 17 |
| `hitstop` | 10 |
| `hitLevel` | 0 |
| `pushback` | 2400 |
| `airPushback` | 2800 |
| `blockPushback` | 1700 |
| `launch` | 1050 |
| `airLaunch` | 1050 |
| `knockdown` | 1 |
| `knockdownFrames` | 12 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 2 |
| `counterVulnerable` | 3 |
| `counterFreezeFrames` | 20 |
| `counterSlowFrames` | 16 |
| `counterHitstun` | 4 |
| `counterHitstop` | 0 |
| `reversalEligible` | 1 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 90 |
| `comboScaling` | 8 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 11 |
| `normalCancelEnd` | 21 |
| `specialCancelStart` | 11 |
| `specialCancelEnd` | 21 |
| `jumpCancelStart` | 11 |
| `jumpCancelEnd` | 19 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active"
    ],
    "groundHit": "use scalar launch/knockdown values",
    "airHit": "use airLaunch and knockdown; current combo gravity applies",
    "block": "mid",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "current velocity-based shared wall rules; wallDamage scalar is inert compatibility metadata",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 20,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 100,
    "startCost": 0,
    "nominalAttackerOnHit": 512,
    "nominalDefenderOnHit": 256,
    "nominalAttackerOnBlock": 256,
    "nominalDefenderOnOrdinaryBlock": 192,
    "defenderOnFDBlock": 0,
    "FDContactCost": 400,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "ordinary current contact event",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 90,
    "decrementAfterEachHit": 8,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 11 | 1 | [[1200, 4400, 7800, 17000], [3200, 12300, 9200, 19800]] |
| 5 | 15 | 1 | [[1200, 4400, 7000, 17000], [3200, 12300, 8400, 19800]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 9 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1100,3800,6200,14100]} |
| 11 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1100,3800,6200,14100]} |
| 16 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1100,3800,4700,14100]} |
| 29 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 5,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 10,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 11,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 15,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 16,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 29,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 44,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From idle/run or an approved contact cancel, coil the right arm near the lower torso while retaining a standing base. Use a grounded rise of the chest and arms, not a jump entry.",
    "support_and_weight": "Both feet stay on the floor; the rear right leg straightens into the planted left leg while the hips remain inside the authored root.",
    "knife_assignment": "Long RIGHT knife reaches the high forward column. Short LEFT opens a compact lower/inner counter-shape beside the ribs, with no separate follow-up hit.",
    "staging": {
      "anticipation": "Draw the right elbow down and inward while the shoulders gather; keep the head visible rather than hiding it behind an invincibility pose.",
      "contact": "Unfold the right arm and blade upward through the tall corridor, emphasizing reach above the body without lifting the feet.",
      "follow_through": "Hold the right elbow high and the torso extended, leaving the front and lower body visibly available to challenge.",
      "retraction": "Lower the right shoulder, gather the short left hand, and soften the knees back into Stalker through the long recovery."
    },
    "geometry_and_visible_weakness": "The authored root stays grounded and the move has no general strike invulnerability. Do not borrow a rising-reversal leap, flash, guard shell or airborne landing branch from the donor.",
    "legal_cancel_bridge": "No outgoing cancel is legal. The high finish must visibly lower before neutral becomes available; do not create an air-normal, jump, Wound or additional rising hit bridge.",
    "whiff_vs_contact": "Whiff emphasizes the high arm and committed lowering motion. Hit gives the opponent the authored launch/reaction; Fillet remains grounded. Block is a checked upper-arm shape during the declared freeze.",
    "facing_authorship": "Keep the tall long-right silhouette identifiable in both facings; the shorter left weapon remains lower and closer rather than becoming a matched second column.",
    "action_name": "Rising carve",
    "source_reference_id": "chipp_2h",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/16.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 22. 4P+K — Back throw

Weak pre-bleed throw reward; side-switches on successful capture.

**Stable slot:** 23. **Input:** 4P+K. **Animation clip:** `fillet_4p_k`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 2 / 2 / 32 |
| Absolute active frames | 2–3 |
| Recovery / next neutral | 4–35; next neutral 36 |
| Block advantage first / last active | — / — |
| Counter | Total shared freeze 6; slow 0 (0 extra held ticks); +0 hitstun; applies=False |
| Ordinary freeze | 6 |
| Entry inertia | 0% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 45 |
| `hitstun` | 14 |
| `blockstun` | 0 |
| `hitstop` | 6 |
| `hitLevel` | 0 |
| `pushback` | 0 |
| `airPushback` | 0 |
| `blockPushback` | 0 |
| `launch` | 0 |
| `airLaunch` | 0 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 0 |
| `counterVulnerable` | 7 |
| `counterFreezeFrames` | 6 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 0 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 100 |
| `comboScaling` | 15 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 2 |
| `normalCancelEnd` | 9 |
| `specialCancelStart` | 2 |
| `specialCancelEnd` | 9 |
| `jumpCancelStart` | 2 |
| `jumpCancelEnd` | 7 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 0,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active",
      "recovery"
    ],
    "groundHit": "explicit paired capture success branch",
    "airHit": "forbidden",
    "block": "not blockable; legal grounded capture only",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "none",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Successful paired branch and failed attempt

```json
{
  "groundedTargetOnly": true,
  "frontOnly": true,
  "localRangeBeyondPushEdges": 2000,
  "centerCaptureBound": "attacker halfwidth + defender halfwidth + 2000; use each defender actual profile",
  "eligibility": "target Free, grounded, not in valid prejump, hitstun, blockstun, throw grace, landing lock, paired post-release lock, capture or knockdown. Ordinary attack startup/active/recovery remains throwable if it has no other protection. Source grounded at capture.",
  "strikeTrade": "A qualifying melee OR projectile strike connecting on the capture tick wins before pair safety starts.",
  "successReplacesRemainingMove": true,
  "captureHitstop": 6,
  "releaseHitstop": 8,
  "pairTicks": 24,
  "actorPostReleaseTicks": 12,
  "victimPostReleaseTicks": 14,
  "advantage": 2,
  "releaseCenterGap": 12000,
  "sideSwitch": true,
  "releaseOutcome": "standing; no knockdown, launcher, wall damage, combo continuation or Wound opportunity",
  "damage": "45; one health event at release",
  "tech": "selected universal C1–C6 unfrozen pair-tick window plus C0 simultaneous clash; see normalThrowTech",
  "whiff": "finish the 2/2/32 action; no hitbox or strike fallback",
  "jumpFailureLatch": {
    "enabled": false,
    "policy": "Ordinary throws test grounded/prejump eligibility on each capture tick. The whole-attempt jump-failure latch belongs only to the two lunging command grabs."
  },
  "bleed": "does not apply, refresh, cash out or remove owned bleed",
  "protectionWarning": "no strike invulnerability on startup or whiff",
  "graceAfterVictimActionability": 5,
  "localCaptureGuideBox": [
    0,
    0,
    4800,
    13800
  ],
  "captureGuidePolicy": "root-local visualization only; actual capture uses two push halfwidths plus throwRange and explicit eligibility"
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 0,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 360,
    "nominalDefenderOnHit": 180,
    "nominalAttackerOnBlock": null,
    "nominalDefenderOnOrdinaryBlock": null,
    "defenderOnFDBlock": 0,
    "FDContactCost": null,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "pay base-damage hit rewards exactly once on successful release; no capture/tech/whiff reward",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 100,
    "decrementAfterEachHit": 15,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

No strike rectangles. Capture uses explicit eligibility and push-edge distance, with a separate non-damaging visualization guide.


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 2 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1400,4700,5800,11200]} |
| 4 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1400,4700,4300,11200]} |
| 19 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry / anticipation / pre-contact",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame. Load the attacking limb; keep the other knife visibly separate. Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 2,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 3,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 4,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 19,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 35,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From a legal grounded neutral entry, bring the already raised left forearm toward the capture area immediately. The short startup cannot contain an extra approach step, large reachback or pre-capture turn. A low pose enters only once the ordinary throw input is legally selected.",
    "support_and_weight": "Keep the left foot as the initial brace and the right foot available for the confirmed paired turn. Do not exchange footing or sides before capture succeeds.",
    "knife_assignment": "LEFT retains the short knife in a closed grip while its forearm/pommel provides the catch shape. RIGHT keeps the long knife low and clear of the partner throughout entry.",
    "staging": {
      "anticipation": "Use a small shoulder compression already present in the entry drawing; avoid a separate anticipatory key that would delay capture.",
      "contact": "Present the left forearm contact shape inside the authored local capture range. Do not draw an empty grabbing hand or blade penetration as the latch.",
      "follow_through": "On success, hand off to normal_throw_backward; the paired guide owns the later turn, side exchange, release and partner reaction. On failure, the left elbow remains extended without any side switch.",
      "retraction": "For whiff, fold the left forearm inward and settle the feet in place. For success, use only the paired guide's post-release recoil and Stalker recovery."
    },
    "geometry_and_visible_weakness": "No weapon hitbox or striking fallback exists. A missed catch must leave a visibly vulnerable extended arm, not a defensive shield or automatic evasion.",
    "legal_cancel_bridge": "No outgoing cancel is legal. Confirmed capture is a success branch, not a cancel into another attack; normal tech uses its own approved break animation.",
    "whiff_vs_contact": "Whiff has no partner tether, damage accent or turn. Confirmed capture establishes the paired contact lock; a valid tech visibly separates that lock instead of playing the completed throw.",
    "facing_authorship": "The back-turn sheet must track the left forearm contact and both knife identities continuously; keep the long right blade in the right hand as both actors exchange sides.",
    "paired_guide": {
      "file": "fillet_movement_animation_baseline.json",
      "path": "movementContract.pairedThrowGuide.contracts",
      "contract_id": "normal_throw_backward",
      "authority": "Central action mechanics and the coordinated paired guide own shared clocks, contact sockets, target motion and release. This brief only stages entry/whiff and the handoff."
    },
    "action_name": "Back throw",
    "source_reference_id": "cammy_capture",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/23.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 23. 6P+K — Forward throw

Weak pre-bleed throw reward; breaks passive blocking and participates in normal throw tech.

**Stable slot:** 24. **Input:** 6P+K. **Animation clip:** `fillet_6p_k`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 2 / 2 / 32 |
| Absolute active frames | 2–3 |
| Recovery / next neutral | 4–35; next neutral 36 |
| Block advantage first / last active | — / — |
| Counter | Total shared freeze 6; slow 0 (0 extra held ticks); +0 hitstun; applies=False |
| Ordinary freeze | 6 |
| Entry inertia | 0% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 45 |
| `hitstun` | 14 |
| `blockstun` | 0 |
| `hitstop` | 6 |
| `hitLevel` | 0 |
| `pushback` | 0 |
| `airPushback` | 0 |
| `blockPushback` | 0 |
| `launch` | 0 |
| `airLaunch` | 0 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 0 |
| `counterVulnerable` | 7 |
| `counterFreezeFrames` | 6 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 0 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 100 |
| `comboScaling` | 15 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 2 |
| `normalCancelEnd` | 9 |
| `specialCancelStart` | 2 |
| `specialCancelEnd` | 9 |
| `jumpCancelStart` | 2 |
| `jumpCancelEnd` | 7 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 0,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active",
      "recovery"
    ],
    "groundHit": "explicit paired capture success branch",
    "airHit": "forbidden",
    "block": "not blockable; legal grounded capture only",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "none",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Successful paired branch and failed attempt

```json
{
  "groundedTargetOnly": true,
  "frontOnly": true,
  "localRangeBeyondPushEdges": 2000,
  "centerCaptureBound": "attacker halfwidth + defender halfwidth + 2000; use each defender actual profile",
  "eligibility": "target Free, grounded, not in valid prejump, hitstun, blockstun, throw grace, landing lock, paired post-release lock, capture or knockdown. Ordinary attack startup/active/recovery remains throwable if it has no other protection. Source grounded at capture.",
  "strikeTrade": "A qualifying melee OR projectile strike connecting on the capture tick wins before pair safety starts.",
  "successReplacesRemainingMove": true,
  "captureHitstop": 6,
  "releaseHitstop": 8,
  "pairTicks": 24,
  "actorPostReleaseTicks": 12,
  "victimPostReleaseTicks": 14,
  "advantage": 2,
  "releaseCenterGap": 12000,
  "sideSwitch": false,
  "releaseOutcome": "standing; no knockdown, launcher, wall damage, combo continuation or Wound opportunity",
  "damage": "45; one health event at release",
  "tech": "selected universal C1–C6 unfrozen pair-tick window plus C0 simultaneous clash; see normalThrowTech",
  "whiff": "finish the 2/2/32 action; no hitbox or strike fallback",
  "jumpFailureLatch": {
    "enabled": false,
    "policy": "Ordinary throws test grounded/prejump eligibility on each capture tick. The whole-attempt jump-failure latch belongs only to the two lunging command grabs."
  },
  "bleed": "does not apply, refresh, cash out or remove owned bleed",
  "protectionWarning": "no strike invulnerability on startup or whiff",
  "graceAfterVictimActionability": 5,
  "localCaptureGuideBox": [
    0,
    0,
    4800,
    13800
  ],
  "captureGuidePolicy": "root-local visualization only; actual capture uses two push halfwidths plus throwRange and explicit eligibility"
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 0,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 360,
    "nominalDefenderOnHit": 180,
    "nominalAttackerOnBlock": null,
    "nominalDefenderOnOrdinaryBlock": null,
    "defenderOnFDBlock": 0,
    "FDContactCost": null,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "pay base-damage hit rewards exactly once on successful release; no capture/tech/whiff reward",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 100,
    "decrementAfterEachHit": 15,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

No strike rectangles. Capture uses explicit eligibility and push-edge distance, with a separate non-damaging visualization guide.


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 2 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1400,4700,5800,11200]} |
| 4 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1400,4700,4300,11200]} |
| 19 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry / anticipation / pre-contact",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame. Load the attacking limb; keep the other knife visibly separate. Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 2,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 3,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 4,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 19,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 35,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From legal grounded neutral, close the small distance between the high left forearm and the capture area without an added step. Run entry stops according to the action contract; a crouching source must first select a legal ordinary-throw entry.",
    "support_and_weight": "Left foot braces the initial catch; the right foot supports the later paired push shape. The pre-capture body remains near Stalker rather than leaning into a long lunge.",
    "knife_assignment": "Short LEFT knife remains in a closed grip with the blade pointing away from the contact. The LEFT forearm/pommel supplies the catch; long RIGHT stays low and visibly clear.",
    "staging": {
      "anticipation": "Compress the left shoulder within the existing entry pose; do not add a conspicuous reachback before the very short capture startup.",
      "contact": "Show a compact left-forearm latch at the actual capture location, with the right hand retaining its weapon outside the partner's silhouette.",
      "follow_through": "On success, hand off to normal_throw_forward for the close-in turn, release and standing separation. On whiff, finish the small unsupported reach without moving the opponent.",
      "retraction": "Whiff brings the left elbow back toward the ribs before returning to the high guard. Success uses the paired guide's independent post-release recovery."
    },
    "geometry_and_visible_weakness": "The catch must not resemble a damaging knife normal. No extra travel, hit spark, wound mark, knockdown preparation or strike fallback is implied.",
    "legal_cancel_bridge": "No outgoing cancel is legal. The paired branch and any normal-tech response use their own contracts; do not draw a throw-to-Wound or throw-to-cashout continuation.",
    "whiff_vs_contact": "Whiff produces an empty-space forearm reach. Capture adds the paired lock cue, and tech opens that lock visibly. The successful ending remains a standing separation rather than a floor slam.",
    "facing_authorship": "Keep the short blade in the anatomical left fist even in the near-camera catch; do not hide an unexplained weapon disappearance behind the victim.",
    "paired_guide": {
      "file": "fillet_movement_animation_baseline.json",
      "path": "movementContract.pairedThrowGuide.contracts",
      "contract_id": "normal_throw_forward",
      "authority": "Central action mechanics and the coordinated paired guide own shared clocks, contact sockets, target motion and release. This brief only stages entry/whiff and the handoff."
    },
    "action_name": "Forward throw",
    "source_reference_id": "cammy_capture",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/24.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 24. D / 5D — Wound

Deliberate grounded OTG application; trades knockdown pressure for a +0 bleed restand.

**Stable slot:** 13. **Input:** D / 5D. **Animation clip:** `fillet_5d`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 24 / 2 / 20 |
| Absolute active frames | 24–25 |
| Recovery / next neutral | 26–45; next neutral 46 |
| Block advantage first / last active | — / — |
| Counter | Total shared freeze 4; slow 0 (0 extra held ticks); +0 hitstun; applies=False |
| Ordinary freeze | 4 |
| Entry inertia | 0% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 0 |
| `hitstun` | 0 |
| `blockstun` | 0 |
| `hitstop` | 4 |
| `hitLevel` | 0 |
| `pushback` | 0 |
| `airPushback` | 0 |
| `blockPushback` | 0 |
| `launch` | 0 |
| `airLaunch` | 0 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 0 |
| `counterVulnerable` | 7 |
| `counterFreezeFrames` | 4 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 0 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 100 |
| `comboScaling` | 0 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 24 |
| `normalCancelEnd` | 31 |
| `specialCancelStart` | 24 |
| `specialCancelEnd` | 31 |
| `jumpCancelStart` | 24 |
| `jumpCancelEnd` | 29 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 1,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active",
      "recovery"
    ],
    "groundHit": "explicit Wound success branch",
    "airHit": "forbidden",
    "block": "does not contact standing/crouching/airborne targets",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "none",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Successful paired branch and failed attempt

```json
{
  "input": "ground D without a recognized cashout motion; disabled while target already carries owned bleed",
  "contact": "only current Downed target with positive downed timer; never AirReel, Waking, wall splat, standing or airborne; require box overlap on either active tick",
  "cancelEntry": false,
  "successReplacesRemainingMove": true,
  "pairTicks": 20,
  "captureHitstop": 4,
  "releaseHitstop": 0,
  "actorPostReleaseTicks": 0,
  "victimPostReleaseTicks": 0,
  "advantage": 0,
  "releaseCenterGap": 12000,
  "damage": 0,
  "postReleaseThrowGrace": 5,
  "reset": [
    "clear knockdown/down/wake timers",
    "clear stun, pending hit travel, launch velocity and incompatible reactions",
    "clear wall-splat/old combo state",
    "place both standing roots within stage",
    "keep facing the opponent",
    "apply bleed at release"
  ],
  "noWhitelist": "availability is produced by startup, route recovery, target downed time and real distance; no source-move eligibility list",
  "windowPolicy": "two active ticks only, no waiting for landing or waking; no refresh if bleed is already active"
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 0,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 0,
    "nominalDefenderOnHit": 0,
    "nominalAttackerOnBlock": null,
    "nominalDefenderOnOrdinaryBlock": null,
    "defenderOnFDBlock": 0,
    "FDContactCost": null,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "Wound gives no start/contact/release meter",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 100,
    "decrementAfterEachHit": 0,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

| Active-relative key | Absolute frame | Hit group | Rectangles — raw units |
| --- | --- | --- | --- |
| 1 | 24 | 1 | [[1800, 0, 9600, 3700]] |
| 2 | 25 | 1 | [[1800, 0, 8800, 3700]] |


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |
| 22 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1200,700,6700,4200]} |
| 24 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1200,700,6700,4200]} |
| 26 | {"legs":[-3400,0,5500,2400],"torsoArms":[-2900,2300,2800,5800],"head":[-1300,5400,2400,7900],"extension":[1200,700,5200,4200]} |
| 35 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      8000
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 12,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 23,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 24,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 25,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 26,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 35,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 45,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "Enter only as the standalone legal grounded Wound attempt, after prior recovery. From idle/run, match the crouched first-action profile immediately and settle the root as specified; from crouch, retain the existing low support. No normal or branch flows directly into it.",
    "support_and_weight": "Plant the left foot near the body and lower the right knee/hip beside it, making a deliberate low working silhouette without adding a step toward the target.",
    "knife_assignment": "Long RIGHT knife stays low and supplies the small Wound contact motif. Short LEFT remains held down/outward; its forearm is available for the later paired support, never an unexplained empty hand.",
    "staging": {
      "anticipation": "Collect the long right blade close to the floor while the head stays focused on the actual downed target; the motion should feel deliberate rather than like a fast sweep.",
      "contact": "Present the low right-blade contact shape only at the authored corridor. A valid downed overlap may begin the paired branch; standing, waking or airborne targets receive no reaction.",
      "follow_through": "On success, hand off to wound_otg_restand: preserve the target's existing prone/supine orientation, then follow the guide's small right-blade mark and assisted rise. On whiff, finish the low gesture alone.",
      "retraction": "Whiff draws the right blade back beside the knee and returns to crouch before the ordinary exit. Success ends through the paired guide with both characters standing."
    },
    "geometry_and_visible_weakness": "Use a restrained status-mark visual, not a large damage slash or floor shockwave. There is no direct health-damage event, expanding OTG radius, automatic step or grab of a waking target.",
    "legal_cancel_bridge": "No cancel entry or exit is legal. A successful paired restand returns to the stated independent free states; the next attack is a fresh action, not an animation chain.",
    "whiff_vs_contact": "Whiff creates no wound mark, partner contact or rise. On confirmed success, the pair animation is distinct; the bleed/status cue appears at the release specified by the central contract, not during the approach.",
    "facing_authorship": "Keep the long right knife low in both views. The left hand must visibly retain the short knife throughout any forearm support during the paired rise.",
    "paired_guide": {
      "file": "fillet_movement_animation_baseline.json",
      "path": "movementContract.pairedThrowGuide.contracts",
      "contract_id": "wound_otg_restand",
      "authority": "Central action mechanics and the coordinated paired guide own shared clocks, contact sockets, target motion and release. This brief only stages entry/whiff and the handoff."
    },
    "action_name": "Wound",
    "source_reference_id": "alan_becker_staging",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/13.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 25. 236D — Vault cashout

Bleed-only lunging command grab; crushes lows during approach and loses to jump.

**Stable slot:** 45. **Input:** 236D. **Animation clip:** `fillet_236d`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 22 / 2 / 30 |
| Absolute active frames | 22–23 |
| Recovery / next neutral | 24–53; next neutral 54 |
| Block advantage first / last active | — / — |
| Counter | Total shared freeze 6; slow 0 (0 extra held ticks); +0 hitstun; applies=False |
| Ordinary freeze | 6 |
| Entry inertia | 0% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 55 |
| `hitstun` | 18 |
| `blockstun` | 0 |
| `hitstop` | 6 |
| `hitLevel` | 0 |
| `pushback` | 0 |
| `airPushback` | 0 |
| `blockPushback` | 0 |
| `launch` | 0 |
| `airLaunch` | 0 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 0 |
| `counterVulnerable` | 7 |
| `counterFreezeFrames` | 6 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 0 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 100 |
| `comboScaling` | 15 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 22 |
| `normalCancelEnd` | 29 |
| `specialCancelStart` | 22 |
| `specialCancelEnd` | 29 |
| `jumpCancelStart` | 22 |
| `jumpCancelEnd` | 27 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 0,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [
      6,
      21
    ],
    "counterVulnerablePhases": [
      "startup",
      "active",
      "recovery"
    ],
    "groundHit": "explicit paired capture success branch",
    "airHit": "forbidden",
    "block": "not blockable; legal grounded capture only",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "none",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Successful paired branch and failed attempt

```json
{
  "groundedTargetOnly": true,
  "frontOnly": true,
  "localRangeBeyondPushEdges": 2000,
  "centerCaptureBound": "attacker halfwidth + defender halfwidth + 2000; use each defender actual profile",
  "eligibility": "target Free, grounded, not in valid prejump, hitstun, blockstun, throw grace, landing lock, paired post-release lock, capture or knockdown. Ordinary attack startup/active/recovery remains throwable if it has no other protection. Source grounded at capture.",
  "strikeTrade": "A qualifying melee OR projectile strike connecting on the capture tick wins before pair safety starts; no capture, no grey snapshot and no status consumption.",
  "successReplacesRemainingMove": true,
  "captureHitstop": 6,
  "releaseHitstop": 8,
  "pairTicks": 28,
  "actorPostReleaseTicks": 16,
  "victimPostReleaseTicks": 18,
  "advantage": 2,
  "releaseCenterGap": 17000,
  "sideSwitch": false,
  "releaseOutcome": "standing; no knockdown, launcher, wall damage, combo continuation or Wound opportunity",
  "damage": "55 + grey-life snapshot, cap160 grey; one health event at release",
  "tech": "not techable",
  "whiff": "finish the 22/2/30 action; no chase or repeat",
  "jumpFailureLatch": {
    "enabled": true,
    "from": "action acceptance",
    "through": "last capture frame23",
    "policy": "Latch failure if target is already airborne or in valid prejump at acceptance, or enters airborne/prejump or accepts any valid jump before the final capture test. Never clear this attempt latch on landing. Still complete whiff recovery."
  },
  "bleed": "snapshot and consume on confirmed capture, remove speed boost immediately",
  "protectionWarning": "All approach evasion ends after21. At22–23 source is grounded with ordinary standing body and push profile. No low-crush or low-profile capture frames.",
  "graceAfterVictimActionability": 5,
  "localCaptureGuideBox": [
    0,
    0,
    4800,
    13800
  ],
  "captureGuidePolicy": "root-local visualization only; actual capture uses two push halfwidths plus throwRange and explicit eligibility"
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 0,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [
      {
        "first": 6,
        "last": 20,
        "dx": 1200,
        "dy": 0,
        "collision": "stop_at_opponent_pushbox; never push target during approach"
      }
    ],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px",
    "verticalRootKeys": [
      {
        "frame": 1,
        "y": 0
      },
      {
        "frame": 5,
        "y": 0
      },
      {
        "frame": 10,
        "y": 2200
      },
      {
        "frame": 15,
        "y": 2200
      },
      {
        "frame": 21,
        "y": 0
      },
      {
        "frame": 22,
        "y": 0
      }
    ],
    "verticalInterpolation": "integer linear interpolation; root samples override normal gravity for this grounded special only, frames6–21; landing gives no separate attack landing lock"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 440,
    "nominalDefenderOnHit": 220,
    "nominalAttackerOnBlock": null,
    "nominalDefenderOnOrdinaryBlock": null,
    "defenderOnFDBlock": 0,
    "FDContactCost": null,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "pay base-damage hit rewards exactly once on successful release; no capture/tech/whiff reward",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 100,
    "decrementAfterEachHit": 15,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

No strike rectangles. Capture uses explicit eligibility and push-edge distance, with a separate non-damaging visualization guide.


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-3200,0,3200,3000],"torsoArms":[-2900,2600,3300,6700],"head":[-1400,6400,2500,9100]} |
| 6 | {"legs":[-2500,400,2500,5700],"torsoArms":[-2500,5300,2800,11000],"head":[-1400,10800,1900,14000],"extension":[1000,5100,5500,11000]} |
| 22 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1400,5000,6100,11500]} |
| 24 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": null,
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 11,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 21,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 22,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 23,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 24,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 38,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 53,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From legal bleed neutral or a designated delayed contact cancel, fold directly into the crouched entry. From a run, discard extra traveling flourish and use only the scripted approach. From a prior attack, bring the left forearm forward while the right knife stays trailing.",
    "support_and_weight": "Load through the right rear leg, let the left knee lead the low vault silhouette, then return the left foot to the floor before capture. The root follows the existing shallow hop keys exactly.",
    "knife_assignment": "LEFT keeps the short knife in a closed grip and leads with its forearm/pommel. Long RIGHT stays low behind the right hip, pointing clear of the opponent during the approach.",
    "staging": {
      "anticipation": "Compress the knees and separate the two knife silhouettes so the launch is readable as a hop approach rather than a slash.",
      "contact": "After the hop has landed, present the left forearm in the upright capture pose. Both feet are grounded; do not animate an aerial latch or continued low-crush posture on the capture frames.",
      "follow_through": "On success, hand off to 236D_hop_cashout from the landed pose. On whiff or latched jump escape, the left arm reaches empty space and the body remains at the finite approach endpoint.",
      "retraction": "Whiff withdraws the left elbow and settles the landed feet in place. Success follows the paired guide's right-blade draw, left accent, release and independent recovery."
    },
    "geometry_and_visible_weakness": "The hop is visibly higher than the skim but remains strike-vulnerable. Approach protection ends before capture; expose the upright body and reaching arm at that transition. No chase, second leap, air catch or extra drift.",
    "legal_cancel_bridge": "No outgoing cancel is legal. The inbound bridge must wait for the central bleed/cancel gate; confirmed capture enters the paired success branch, while every failed attempt completes the authored whiff path.",
    "whiff_vs_contact": "Whiff has no lock or cashout flash, and a jumping target is not followed upward or recaptured on landing. Successful capture changes the status cue at the specified consume event; release carries the single cashout impact.",
    "facing_authorship": "Redraw the lifted knee, left forearm and trailing right knife for both facings. The longer blade must not switch to the leading catch arm.",
    "paired_guide": {
      "file": "fillet_movement_animation_baseline.json",
      "path": "movementContract.pairedThrowGuide.contracts",
      "contract_id": "236D_hop_cashout",
      "authority": "Central action mechanics and the coordinated paired guide own shared clocks, contact sockets, target motion and release. This brief only stages entry/whiff and the handoff."
    },
    "action_name": "Vault cashout",
    "source_reference_id": "cammy_capture",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/45.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## 26. 214D — Skim cashout

Bleed-only low-profile command grab; evades sufficiently high boxes and loses to lows/jump.

**Stable slot:** 46. **Input:** 214D. **Animation clip:** `fillet_214d`.

| Property | Selected result |
| --- | --- |
| Startup / active / recovery | 22 / 2 / 30 |
| Absolute active frames | 22–23 |
| Recovery / next neutral | 24–53; next neutral 54 |
| Block advantage first / last active | — / — |
| Counter | Total shared freeze 6; slow 0 (0 extra held ticks); +0 hitstun; applies=False |
| Ordinary freeze | 6 |
| Entry inertia | 0% |

### Hit result and push

| Scalar | Value |
| --- | --- |
| `damage` | 55 |
| `hitstun` | 18 |
| `blockstun` | 0 |
| `hitstop` | 6 |
| `hitLevel` | 0 |
| `pushback` | 0 |
| `airPushback` | 0 |
| `blockPushback` | 0 |
| `launch` | 0 |
| `airLaunch` | 0 |
| `knockdown` | 0 |
| `knockdownFrames` | 6 |
| `wakeupFrames` | 8 |
| `hitAngle` | 0 |
| `chipDamage` | 0 |
| `guardBreak` | 0 |
| `groundBounce` | 0 |
| `wallBounce` | 0 |
| `crumpleFrames` | 0 |
| `airCounterKnockdown` | 0 |

### Counter, vulnerability and landing

| Scalar | Value |
| --- | --- |
| `counterTier` | 0 |
| `counterVulnerable` | 7 |
| `counterFreezeFrames` | 6 |
| `counterSlowFrames` | 0 |
| `counterHitstun` | 0 |
| `counterHitstop` | 0 |
| `reversalEligible` | 0 |
| `hurtMaskWindup` | 15 |
| `hurtMaskActive` | 15 |
| `hurtMaskRecovery` | 15 |
| `hurtWindowStart` | 0 |
| `hurtWindowEnd` | 0 |
| `hurtWindowMask` | 15 |
| `semiAirStart` | 0 |
| `semiAirEnd` | 0 |
| `armorFrames` | 0 |
| `armorHits` | 0 |
| `landingRecovery` | 0 |

### Scaling and route windows

| Scalar | Value |
| --- | --- |
| `starterProration` | 100 |
| `comboScaling` | 15 |
| `minimumDamage` | 10 |
| `normalCancelStart` | 22 |
| `normalCancelEnd` | 29 |
| `specialCancelStart` | 22 |
| `specialCancelEnd` | 29 |
| `jumpCancelStart` | 22 |
| `jumpCancelEnd` | 27 |
| `followCancelStart` | 1 |
| `followCancelEnd` | 0 |
| `cancelOn` | 3 |
| `followFrom` | -1 |
| `followFrom2` | -1 |
| `followHit` | 0 |
| `proximityMove` | -1 |
| `proximityRange` | 10500 |

### Contact predicates and complete routes

```json
{
  "contacts": {
    "groups": 0,
    "rehit": false,
    "armor": false,
    "projectile": false,
    "guardPoint": false,
    "strikeInvulnerability": "none",
    "throwInvulnerability": "none from ordinary attack recovery; universal prejump/air, stun/grace, protected landing and paired-state predicates remain applicable",
    "lowCrushFrames": [],
    "counterVulnerablePhases": [
      "startup",
      "active",
      "recovery"
    ],
    "groundHit": "explicit paired capture success branch",
    "airHit": "forbidden",
    "block": "not blockable; legal grounded capture only",
    "wallBounce": false,
    "groundBounce": false,
    "crumple": false,
    "wallBreak": "none",
    "simultaneousPriority": "Classify melee and projectile strikes before capture arbitration. Any simultaneously connecting qualifying strike defeats capture without consuming bleed. Ordinary strike trades use shared core rules."
  },
  "cancels": {
    "normalTargets": [],
    "normalCondition": "hit_or_block",
    "specialTargets": [],
    "specialCondition": "hit_or_block",
    "jumpCondition": "none",
    "dashCancel": "air-only when jumpCancel is legal and an air-dash use remains; no grounded dash-cancel",
    "followTargets": [],
    "followWindow": null,
    "followCondition": "none",
    "bleedGrabTargets": [],
    "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
    "proximityOnCancel": "c.S to 5S explicitly forces f.S, bypassing close-proximity redispatch; no c.S loop",
    "woundCancel": false,
    "whiffCancel": false,
    "rc": "disabled in this v1 implementation; R/P/Y future, blue excluded"
  }
}
```

### Successful paired branch and failed attempt

```json
{
  "groundedTargetOnly": true,
  "frontOnly": true,
  "localRangeBeyondPushEdges": 2000,
  "centerCaptureBound": "attacker halfwidth + defender halfwidth + 2000; use each defender actual profile",
  "eligibility": "target Free, grounded, not in valid prejump, hitstun, blockstun, throw grace, landing lock, paired post-release lock, capture or knockdown. Ordinary attack startup/active/recovery remains throwable if it has no other protection. Source grounded at capture.",
  "strikeTrade": "A qualifying melee OR projectile strike connecting on the capture tick wins before pair safety starts; no capture, no grey snapshot and no status consumption.",
  "successReplacesRemainingMove": true,
  "captureHitstop": 6,
  "releaseHitstop": 8,
  "pairTicks": 28,
  "actorPostReleaseTicks": 16,
  "victimPostReleaseTicks": 18,
  "advantage": 2,
  "releaseCenterGap": 17000,
  "sideSwitch": false,
  "releaseOutcome": "standing; no knockdown, launcher, wall damage, combo continuation or Wound opportunity",
  "damage": "55 + grey-life snapshot, cap160 grey; one health event at release",
  "tech": "not techable",
  "whiff": "finish the 22/2/30 action; no chase or repeat",
  "jumpFailureLatch": {
    "enabled": true,
    "from": "action acceptance",
    "through": "last capture frame23",
    "policy": "Latch failure if target is already airborne or in valid prejump at acceptance, or enters airborne/prejump or accepts any valid jump before the final capture test. Never clear this attempt latch on landing. Still complete whiff recovery."
  },
  "bleed": "snapshot and consume on confirmed capture, remove speed boost immediately",
  "protectionWarning": "All approach evasion ends after21. At22–23 source is grounded with ordinary standing body and push profile. No low-crush or low-profile capture frames.",
  "graceAfterVictimActionability": 5,
  "localCaptureGuideBox": [
    0,
    0,
    4800,
    13800
  ],
  "captureGuidePolicy": "root-local visualization only; actual capture uses two push halfwidths plus throwRange and explicit eligibility"
}
```

### Momentum, root travel, facing and resources

```json
{
  "movement": {
    "entryInertiaPercent": 0,
    "instantAdvance": 0,
    "startupTravelPerTick": 0,
    "activeTravelPerTick": 0,
    "attackFrictionPerTick": 90,
    "rootTrack": [
      {
        "first": 6,
        "last": 20,
        "dx": 1200,
        "dy": 0,
        "collision": "stop_at_opponent_pushbox; never push target during approach"
      }
    ],
    "facing": "lock at entry",
    "bleedScalesAuthoredTravel": false,
    "rootVSArt": "gameplay root follows these integers; local body settle is visual and bounded to 4px"
  },
  "meterAndScaling": {
    "unitsPerPercent": 100,
    "startGain": 0,
    "startCost": 0,
    "nominalAttackerOnHit": 440,
    "nominalDefenderOnHit": 220,
    "nominalAttackerOnBlock": null,
    "nominalDefenderOnOrdinaryBlock": null,
    "defenderOnFDBlock": 0,
    "FDContactCost": null,
    "notes": "Rates use raw base damage, not chip or scaled health loss. Positive bonus and meter cap still apply. FD continuous drain is separate. Grey cashout does not add meter.",
    "pairedEvent": "pay base-damage hit rewards exactly once on successful release; no capture/tech/whiff reward",
    "firstHitScaling": 100,
    "followupScaling": "max(current move minimumDamage, floor(starterProration * accumulatedComboScale /100)) percent",
    "starterProration": 100,
    "decrementAfterEachHit": 15,
    "minimumDamagePercent": 10,
    "chipOnOrdinaryBlock": 0,
    "chipOnFD": 0,
    "counterDamageMultiplier": 100,
    "knockdownAndCapture": "paired success is a fresh non-combo capture; follow-up combo continuation is prohibited; grey is added after base damage"
  }
}
```

### Exact attack rectangles

No strike rectangles. Capture uses explicit eligibility and push-edge distance, with a separate non-damaging visualization guide.


### Exact anatomical rectangles

| Absolute key | Regions — raw units |
| --- | --- |
| 1 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 6 | {"legs":[-3400,0,4400,1800],"torsoArms":[-2500,1600,4800,3800],"head":[3100,3400,5500,5200],"extension":[2500,1400,6200,3900]} |
| 22 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600],"extension":[1800,6200,6100,11600]} |
| 24 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |
| 39 | {"legs":[-5400,0,6000,6200],"torsoArms":[-3600,5200,3500,11800],"head":[500,11800,3200,14600]} |


No additional anatomy mask beyond the explicitly listed scalar/window contract.

### Push shape and pose schedule

```json
{
  "pushbox": {
    "ground": [
      -2800,
      0,
      2800,
      13800
    ],
    "air": [
      -2800,
      5000,
      2800,
      14000
    ],
    "policy": "authoritative body push shape; no weapon area"
  },
  "pushboxTimeline": {
    "basis": "absolute action frames; hold until next key",
    "keys": [
      {
        "frame": 1,
        "box": [
          -2800,
          0,
          2800,
          13800
        ]
      },
      {
        "frame": 6,
        "box": [
          -2800,
          0,
          2800,
          5200
        ]
      },
      {
        "frame": 22,
        "box": [
          -2800,
          0,
          2800,
          13800
        ]
      }
    ]
  },
  "poseKeys": [
    {
      "frame": 1,
      "label": "entry",
      "guide": "Read source body/feet; capture the start silhouette without delaying this frame."
    },
    {
      "frame": 11,
      "label": "anticipation",
      "guide": "Load the attacking limb; keep the other knife visibly separate."
    },
    {
      "frame": 21,
      "label": "pre-contact",
      "guide": "Lead hand/foot approaches the contact corridor; no damaging trail yet."
    },
    {
      "frame": 22,
      "label": "active",
      "guide": "Match the exact red attack rectangles and green anatomical profile on this frame."
    },
    {
      "frame": 23,
      "label": "follow-through",
      "guide": "Only listed active boxes remain damaging; a fading trail adds no reach."
    },
    {
      "frame": 24,
      "label": "recovery",
      "guide": "Weapon exits target; exposed extension remains until the authored retraction key."
    },
    {
      "frame": 38,
      "label": "retract",
      "guide": "Hands return toward guard; action is still locked until the listed terminal tick."
    },
    {
      "frame": 53,
      "label": "last locked",
      "guide": "Match the ready/crouch/air exit silhouette; no visual snap may change the action clock."
    }
  ]
}
```

### Animation and state transfers

```json
{
  "entrySources": [
    "idle",
    "walk",
    "run",
    "backdash frames5+"
  ],
  "impactInsert": "conditional contact pose held only for declared shared hitstop; whiff skips impact without changing action duration",
  "exit": "idle, crouch, walk or run according to legal buffered input on next actionable tick",
  "interrupt": "strike -> actual hit reaction immediately; legal cancel -> next action entry; no uninterruptible visual recovery after gameplay release",
  "specificStaging": {
    "entry": "From legal bleed neutral or a designated delayed contact cancel, begin with the ordinary standing entry, then compress into the authored low approach. A crouched source stays compact but must still respect the entry profile and actual timeline; no early low-profile shortcut.",
    "support_and_weight": "Keep the left leg folded under the low torso and the right boot trailing near the floor. The head and left forearm lead the skim; the hips remain low over the existing horizontal root path.",
    "knife_assignment": "Short LEFT knife stays in a closed grip with its forearm leading. Long RIGHT is carried flat and trailing beside the right side, visibly clear of the floor-contact and capture motif.",
    "staging": {
      "anticipation": "Fold the shoulders and hips into a flattened silhouette before the approach key. Keep both knife lengths readable even while the limbs compress.",
      "contact": "At frame22 rise fully into ordinary standing body and push height, reach with the LEFT forearm while retaining the short knife, and attempt one grounded capture. Low-profile protection ends after frame21.",
      "follow_through": "On success, hand off to 214D_slide_cashout, letting its first paired poses gather the crouched approach into the upright hold. On whiff, leave the left forearm extended from the low seat without pursuing.",
      "retraction": "On failure retract the reaching arm into standing Stalker from frame24 and complete recovery through53; no lingering crouched evasion."
    },
    "geometry_and_visible_weakness": "Fit the entire active low-profile body under its authored top, then visibly lose that profile before capture. Keep the legs and leading forearm exposed to intersecting lows; no burrow, translucency, blade hitbox or all-mid immunity.",
    "legal_cancel_bridge": "No outgoing cancel is legal. The entry from pressure must obey the same delayed bleed gate as the vault, and the whiff cannot become a sweep, hop or second grab.",
    "whiff_vs_contact": "Whiff is a low unsupported reach followed by a visible rise; no victim lock, status consumption or impact flourish. On success, the paired catch is the only route to the later cashout sequence.",
    "facing_authorship": "In the reverse-facing sheet, keep the anatomical left forearm foremost and the long right blade trailing. Do not use a mirrored slide that swaps weapons or lifts the body above the fitted low silhouette.",
    "paired_guide": {
      "file": "fillet_movement_animation_baseline.json",
      "path": "movementContract.pairedThrowGuide.contracts",
      "contract_id": "214D_slide_cashout",
      "authority": "Central action mechanics and the coordinated paired guide own shared clocks, contact sockets, target motion and release. This brief only stages entry/whiff and the handoff."
    },
    "action_name": "Skim cashout",
    "source_reference_id": "cammy_capture",
    "status": "selected_for_v1_implementation",
    "anchor_binding": "Use this action’s existing entry/anticipation/pre-contact/active/follow-through/recovery/retract/last-locked keys. These notes introduce no new frame durations or contact events; confirmed pair branches use their separate C clock.",
    "outgoing_routes_from_central_contract": {
      "normalTargets": [],
      "normalCondition": "hit_or_block",
      "specialTargets": [],
      "specialCondition": "hit_or_block",
      "followTargets": [],
      "followWindow": null,
      "followCondition": "none",
      "jumpCondition": "none",
      "bleedGrabTargets": [],
      "bleedGrabCondition": "requires owned bleed; at least 5 completed attacker action ticks since last contact; within special/follow window",
      "woundCancel": false,
      "whiffCancel": false
    }
  }
}
```

Geometry sheet: `geometry/46.svg`. Read the action's complete production paragraph in `ANIMATION_AND_ART.md` and source mapping in `VISUAL_REFERENCE_INDEX.md`. The implementation must create the full playable clip, not hold the donor image.

## Disabled Fillet slots

Keep these stable IDs for serialization; set enabled=0 for Fillet. Do not remove/reorder existing cast slots or disable other characters’ attacks. Append command-grab slots disabled for other characters.

| Slot | ID | Reason |
| --- | --- | --- |
| 9 | 6K | No independent reset normal in this v1 implementation; 5K and 236S supply distinct pressure roles. |
| 10 | 6S | Retired redundant command poke; f.S and 6Hs own its neutral/chase work. |
| 12 | 6D | Drive is Wound plus two motion cashouts; no additional directional Drive attack. |
| 21 | j.D | No air Drive action in this v1 implementation. |
| 22 | 2D | Fillet uses current2S sweep and Drive-onlyD. Disable this Fillet slot; preserve other characters’ current2D/Drive behavior. |
| 28 | 214S | Shark/tether compatibility slot, not part of Fillet kit. |
| 29 | j.214P | Shark/tether compatibility slot, not part of Fillet kit. |
| 30 | 214S>P | Shark/tether followup compatibility slot, not part of Fillet kit. |
| 31 | j.214P>P | Shark/tether followup compatibility slot, not part of Fillet kit. |
| 33 | [S/Hs] | Held guard/stance not part of this Fillet v1 implementation. |
| 34 | [S/Hs]>attack | Guard follow-up not part of this Fillet v1 implementation. |
| 35 | st.P | No stance kit. |
| 36 | st.K | No stance kit. |
| 37 | st.S | No stance kit. |
| 38 | st.Hs | No stance kit. |
| 39 | st.2D | No stance exit action. |
| 40 | st.236D | No stance command throw. |
| 41 | j.4P+K | Air throws not part of this Fillet v1 implementation. |
| 42 | j.6P+K | Air throws not part of this Fillet v1 implementation. |
| 43 | 6[Hs] | No charged heavy in this v1 implementation. |
| 44 | 5[D] | No charged Drive in this v1 implementation. |


## Remaining scalar fields

Every scalar not repeated in these readable tables remains explicitly selected in `FINAL_MOVE_VALUES.json`. In particular, the inactive projectile/tether/stance/smear variants and legacy art compatibility values are not permission to enable those mechanics. `enabled`, action categories, input mappings and the sidecar types determine applicability. Do not infer absent effects from nonzero compatibility defaults. `PROPERTY_REFERENCE.json` provides their definitions and the baseline source citations.
